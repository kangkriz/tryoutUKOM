import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole, AccountStatus, Question, ExamResult, KisiKisi, Announcement, CBTActiveState, NURSE_CATEGORIES } from '../types';
import { repository } from '../firebase';
import { SAMPLE_QUESTIONS } from '../data/sampleQuestions';

interface AppContextType {
  currentUser: User | null;
  users: User[];
  questions: Question[];
  results: ExamResult[];
  kisiKisi: KisiKisi[];
  announcements: Announcement[];
  loading: boolean;
  theme: 'light' | 'dark';
  
  // CBT active state
  cbtState: CBTActiveState | null;
  cbtQuestions: Question[];

  // Actions
  login: (email: string, role: UserRole) => Promise<User | null>;
  logout: () => void;
  toggleTheme: () => void;

  // Real-time Firestore or LS sync updates
  addUser: (user: User) => Promise<void>;
  updateUserStatus: (userId: string, status: AccountStatus) => Promise<void>;
  deleteUser: (userId: string) => Promise<void>;

  addQuestion: (q: Question) => Promise<void>;
  deleteQuestion: (id: string) => Promise<void>;

  addKisiKisi: (kisi: KisiKisi) => Promise<void>;
  deleteKisiKisi: (id: string) => Promise<void>;

  addAnnouncement: (ann: Announcement) => Promise<void>;
  deleteAnnouncement: (id: string) => Promise<void>;

  // CBT Mechanics
  startCBT: (customQuestionsCount?: number, targetCategory?: string, targetModel?: string) => void;
  setAnswerForCBT: (questionId: string, option: string) => void;
  toggleFlagCBT: (questionId: string) => void;
  setCurrentIndexCBT: (idx: number) => void;
  tickTimerCBT: () => void;
  submitCBT: () => Promise<ExamResult>;
  cancelCBT: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('cbt_logged_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [users, setUsers] = useState<User[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [results, setResults] = useState<ExamResult[]>([]);
  const [kisiKisi, setKisiKisi] = useState<KisiKisi[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem('cbt_theme');
      return (saved as 'light' | 'dark') || 'light';
    } catch {
      return 'light';
    }
  });

  // Active CBT States
  const [cbtState, setCbtState] = useState<CBTActiveState | null>(() => {
    try {
      const saved = localStorage.getItem('cbt_active_state');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [cbtQuestions, setCbtQuestions] = useState<Question[]>(() => {
    try {
      const saved = localStorage.getItem('cbt_active_questions');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Sync data on startup
  async function loadAllData() {
    setLoading(true);
    try {
      const [u, q, r, k, a] = await Promise.all([
        repository.getUsers(),
        repository.getQuestions(),
        repository.getResults(),
        repository.getKisiKisi(),
        repository.getAnnouncements()
      ]);
      setUsers(u);
      setQuestions(q);
      setResults(r);
      setKisiKisi(k);
      setAnnouncements(a);
    } catch (e) {
      console.error("Error loading hybrid data:", e);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAllData();
  }, []);

  // Theme support class update
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('cbt_theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  // Local storage caching for active CBT state (protect from random refreshes)
  useEffect(() => {
    if (cbtState) {
      localStorage.setItem('cbt_active_state', JSON.stringify(cbtState));
    } else {
      localStorage.removeItem('cbt_active_state');
    }
  }, [cbtState]);

  useEffect(() => {
    if (cbtQuestions.length > 0) {
      localStorage.setItem('cbt_active_questions', JSON.stringify(cbtQuestions));
    } else {
      localStorage.removeItem('cbt_active_questions');
    }
  }, [cbtQuestions]);

  // Auth operations
  const login = async (email: string, role: UserRole): Promise<User | null> => {
    // Search default or custom seeded users
    const matched = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (matched) {
      if (matched.status === AccountStatus.INACTIVE) {
        throw new Error("Akun Anda telah dinonaktifkan oleh administrator.");
      }
      setCurrentUser(matched);
      localStorage.setItem('cbt_logged_user', JSON.stringify(matched));
      return matched;
    } else if (email.includes('@')) {
       // Create a quick custom user or return null
       const newUser: User = {
         id: `u-${Date.now()}`,
         name: email.split('@')[0].toUpperCase(),
         email: email,
         role: role,
         status: AccountStatus.ACTIVE,
         createdAt: new Date().toISOString()
       };
       await repository.saveUser(newUser);
       setUsers(prev => [...prev, newUser]);
       setCurrentUser(newUser);
       localStorage.setItem('cbt_logged_user', JSON.stringify(newUser));
       return newUser;
    }
    return null;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('cbt_logged_user');
    setCbtState(null);
    setCbtQuestions([]);
  };

  // Participant updates
  const addUser = async (user: User) => {
    await repository.saveUser(user);
    setUsers(prev => {
      const idx = prev.findIndex(u => u.id === user.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = user;
        return next;
      }
      return [...prev, user];
    });
  };

  const updateUserStatus = async (userId: string, status: AccountStatus) => {
    const uIdx = users.findIndex(u => u.id === userId);
    if (uIdx >= 0) {
      const updatedUser = { ...users[uIdx], status };
      await repository.saveUser(updatedUser);
      setUsers(prev => {
        const next = [...prev];
        next[uIdx] = updatedUser;
        return next;
      });
      if (currentUser?.id === userId) {
        setCurrentUser(updatedUser);
        localStorage.setItem('cbt_logged_user', JSON.stringify(updatedUser));
      }
    }
  };

  const deleteUser = async (userId: string) => {
    await repository.deleteUser(userId);
    setUsers(prev => prev.filter(u => u.id !== userId));
  };

  // Questions database
  const addQuestion = async (q: Question) => {
    await repository.saveQuestion(q);
    setQuestions(prev => {
      const idx = prev.findIndex(item => item.id === q.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = q;
        return next;
      }
      return [...prev, q];
    });
  };

  const deleteQuestion = async (id: string) => {
    await repository.deleteQuestion(id);
    setQuestions(prev => prev.filter(q => q.id !== id));
  };

  // Kisi-Kisi database
  const addKisiKisi = async (kisi: KisiKisi) => {
    await repository.saveKisiKisi(kisi);
    setKisiKisi(prev => {
      const idx = prev.findIndex(k => k.id === kisi.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = kisi;
        return next;
      }
      return [...prev, kisi];
    });
  };

  const deleteKisiKisi = async (id: string) => {
    await repository.deleteKisiKisi(id);
    setKisiKisi(prev => prev.filter(k => k.id !== id));
  };

  // Announcements database
  const addAnnouncement = async (ann: Announcement) => {
    await repository.saveAnnouncement(ann);
    setAnnouncements(prev => {
      const idx = prev.findIndex(a => a.id === ann.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = ann;
        return next;
      }
      return [...prev, ann];
    });
  };

  const deleteAnnouncement = async (id: string) => {
    await repository.deleteAnnouncement(id);
    setAnnouncements(prev => prev.filter(a => a.id !== id));
  };


  // --- CBT ENGINE / MEKANIKA SOAL ---

  // Start Exam session. Can customize number of items and shuffle option.
  const startCBT = (customQuestionsCount: number = 180, targetCategory?: string, targetModel?: string) => {
    let selectedArr = [...questions];
    
    // Filter by model if requested
    if (targetModel) {
      selectedArr = selectedArr.filter(q => q.model === targetModel);
    }

    // Filter by nursing subfield category if requested
    if (targetCategory) {
      selectedArr = selectedArr.filter(q => q.category === targetCategory);
    }

    // Default 180 questions configuration. Shuffle layout dynamically!
    selectedArr.sort(() => Math.random() - 0.5);
    selectedArr = selectedArr.slice(0, customQuestionsCount);

    if (selectedArr.length === 0) {
      // Create backup fallback from Sample Questions if empty
      let fallback = [...SAMPLE_QUESTIONS];
      if (targetModel) {
        fallback = fallback.filter(q => q.model === targetModel);
      }
      if (targetCategory) {
        fallback = fallback.filter(q => q.category === targetCategory);
      }
      selectedArr = fallback.slice(0, customQuestionsCount);
      if (selectedArr.length === 0) {
        selectedArr = [...SAMPLE_QUESTIONS].slice(0, customQuestionsCount);
      }
    }

    const durationMinutes = targetCategory ? Math.max(30, selectedArr.length * 1) : 180; // Standard D3 UKOM = 1 min per question

    setCbtQuestions(selectedArr);
    setCbtState({
      answers: {},
      flagged: [],
      currentQuestionIndex: 0,
      timeRemainingSeconds: durationMinutes * 60,
      isActive: true,
      isCompleted: false,
      isFullscreen: false
    });
  };

  const setAnswerForCBT = (questionId: string, option: string) => {
    setCbtState(prev => {
      if (!prev) return null;
      return {
        ...prev,
        answers: {
          ...prev.answers,
          [questionId]: option
        }
      };
    });
  };

  const toggleFlagCBT = (questionId: string) => {
    setCbtState(prev => {
      if (!prev) return null;
      const isAlreadyFlagged = prev.flagged.includes(questionId);
      return {
        ...prev,
        flagged: isAlreadyFlagged
          ? prev.flagged.filter(id => id !== questionId)
          : [...prev.flagged, questionId]
      };
    });
  };

  const setCurrentIndexCBT = (idx: number) => {
    setCbtState(prev => {
      if (!prev) return null;
      return {
        ...prev,
        currentQuestionIndex: idx
      };
    });
  };

  const tickTimerCBT = () => {
    setCbtState(prev => {
      if (!prev) return null;
      if (prev.timeRemainingSeconds <= 1) {
        // Submit instantly on timeout
        return {
          ...prev,
          timeRemainingSeconds: 0,
          isCompleted: true,
          isActive: false
        };
      }
      return {
        ...prev,
        timeRemainingSeconds: prev.timeRemainingSeconds - 1
      };
    });
  };

  const submitCBT = async (): Promise<ExamResult> => {
    if (!cbtState || !currentUser) {
      throw new Error("Sesi ujian tidak aktif.");
    }

    let correctCount = 0;
    cbtQuestions.forEach(q => {
      const studentAns = cbtState.answers[q.id];
      if (studentAns === q.correctAnswer) {
        correctCount++;
      }
    });

    const totalQuestions = cbtQuestions.length;
    const score = totalQuestions > 0 ? parseFloat(((correctCount / totalQuestions) * 100).toFixed(1)) : 0;
    const wrongCount = totalQuestions - correctCount;
    // Standard passing percentage grade for D3 Keperawatan UKOM is generally around 55% - 60%
    const isPassed = score >= 55; 

    const newResult: ExamResult = {
      id: `res-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      score,
      correctCount,
      wrongCount,
      percentage: score,
      isPassed,
      answers: cbtState.answers,
      flagged: cbtState.flagged,
      completedAt: new Date().toISOString()
    };

    // Save using hybrid repository
    await repository.saveResult(newResult);
    
    // Update local context outcomes
    setResults(prev => [newResult, ...prev]);

    // Cleanup exam state
    setCbtState(null);

    return newResult;
  };

  const cancelCBT = () => {
    setCbtState(null);
    setCbtQuestions([]);
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      users,
      questions,
      results,
      kisiKisi,
      announcements,
      loading,
      theme,
      cbtState,
      cbtQuestions,
      login,
      logout,
      toggleTheme,
      addUser,
      updateUserStatus,
      deleteUser,
      addQuestion,
      deleteQuestion,
      addKisiKisi,
      deleteKisiKisi,
      addAnnouncement,
      deleteAnnouncement,
      startCBT,
      setAnswerForCBT,
      toggleFlagCBT,
      setCurrentIndexCBT,
      tickTimerCBT,
      submitCBT,
      cancelCBT
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return context;
}
