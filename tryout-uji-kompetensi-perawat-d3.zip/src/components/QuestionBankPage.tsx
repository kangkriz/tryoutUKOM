import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Search, PlusCircle, Trash, RefreshCcw, Sparkles, BookOpen, AlertCircle, Eye, CheckCircle, UploadCloud, FileText, Check, Edit3, Save, X, HelpCircle, Layers, ChevronRight } from 'lucide-react';
import { Question } from '../types';
import mammoth from 'mammoth';

export default function QuestionBankPage() {
  const { questions, addQuestion, deleteQuestion } = useApp();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [modelFilter, setModelFilter] = useState('');
  
  // Tabs
  const [activeFormTab, setActiveFormTab] = useState<'list' | 'manual' | 'ai'>('list');

  // Manual Form State
  const [category, setCategory] = useState('Keperawatan Medikal Bedah (KMB)');
  const [questionText, setQuestionText] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [optionA, setOptionA] = useState('');
  const [optionB, setOptionB] = useState('');
  const [optionC, setOptionC] = useState('');
  const [optionD, setOptionD] = useState('');
  const [optionE, setOptionE] = useState('');
  const [correctAnswer, setCorrectAnswer] = useState('A');
  const [explanation, setExplanation] = useState('');
  const [success, setSuccess] = useState('');
  
  // Model selector for manual and import
  const [selectedModel, setSelectedModel] = useState('Model 1');
  const [customModelName, setCustomModelName] = useState('');
  const [showCustomModelInput, setShowCustomModelInput] = useState(false);

  // File Upload and AI Parser States
  const [rawText, setRawText] = useState('');
  const [importFileName, setImportFileName] = useState('');
  const [importError, setImportError] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [fileLoading, setFileLoading] = useState(false);

  // Temporary list of questions parsed from file/AI for review before saving
  const [parsedQuestions, setParsedQuestions] = useState<Question[]>([]);
  const [editingParsedIndex, setEditingParsedIndex] = useState<number | null>(null);
  
  // Edit Form for Parsed Questions Review
  const [editQCategory, setEditQCategory] = useState('');
  const [editQText, setEditQText] = useState('');
  const [editQOptionA, setEditQOptionA] = useState('');
  const [editQOptionB, setEditQOptionB] = useState('');
  const [editQOptionC, setEditQOptionC] = useState('');
  const [editQOptionD, setEditQOptionD] = useState('');
  const [editQOptionE, setEditQOptionE] = useState('');
  const [editQCorrectAnswer, setEditQCorrectAnswer] = useState<'A' | 'B' | 'C' | 'D' | 'E'>('A');
  const [editQExplanation, setEditQExplanation] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Categories list
  const categories = Array.from(new Set(questions.map((q) => q.category)));

  // Models list
  const detectedModels = Array.from(new Set(questions.map((q) => q.model || 'Model 1'))) as string[];
  const models: string[] = detectedModels.length > 0 ? detectedModels : ['Model 1', 'Model 2', 'Model 3'];

  // Calculate model statistics
  const getModelStats = (modelName: string) => {
    const count = questions.filter(q => (q.model || 'Model 1') === modelName).length;
    const target = 180;
    const percentage = Math.min(100, Math.floor((count / target) * 100));
    return { count, target, percentage };
  };

  // Form submit handler for manual entry
  const handleSaveQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText || !optionA || !optionB || !optionC || !optionD || !optionE) {
       alert('Harap lengkapi semua isian pertanyaan serta opsi pilihan ganda.');
       return;
    }

    const finalModel = showCustomModelInput ? customModelName.trim() : selectedModel;
    if (showCustomModelInput && !customModelName.trim()) {
      alert('Nama Model baru tidak boleh kosong!');
      return;
    }

    const newQ: Question = {
       id: `q-${Date.now()}`,
       category,
       question: questionText,
       imageUrl: imageUrl.trim() || undefined,
       optionA,
       optionB,
       optionC,
       optionD,
       optionE,
       correctAnswer: correctAnswer as any,
       explanation,
       model: finalModel || 'Model 1',
       createdAt: new Date().toISOString()
    };

    await addQuestion(newQ);
    resetManualForm();
    setSuccess(`Pertanyaan manual disimpan ke ${finalModel}!`);
    setActiveFormTab('list');
    setTimeout(() => setSuccess(''), 3000);
  };

  const resetManualForm = () => {
    setQuestionText('');
    setImageUrl('');
    setOptionA('');
    setOptionB('');
    setOptionC('');
    setOptionD('');
    setOptionE('');
    setCorrectAnswer('A');
    setExplanation('');
    setCustomModelName('');
    setShowCustomModelInput(false);
  };

  // Document File Reader client-side helper
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportFileName(file.name);
    setImportError('');
    setFileLoading(true);
    setSuccess('');

    const fileExtension = file.name.split('.').pop()?.toLowerCase();

    try {
      if (fileExtension === 'txt') {
        const reader = new FileReader();
        reader.onload = (event) => {
          const text = event.target?.result as string;
          setRawText(text);
          setFileLoading(false);
          setSuccess('File Teks (.txt) berhasil dimuat. Siap diproses AI!');
        };
        reader.onerror = () => {
          setImportError('Gagal membaca file .txt.');
          setFileLoading(false);
        };
        reader.readAsText(file);
      } else if (fileExtension === 'docx') {
        const reader = new FileReader();
        reader.onload = async (event) => {
          try {
            const arrayBuffer = event.target?.result as ArrayBuffer;
            const res = await mammoth.extractRawText({ arrayBuffer });
            setRawText(res.value);
            setFileLoading(false);
            setSuccess('File Word (.docx) berhasil diekstrak. Siap diproses AI!');
          } catch (err: any) {
            setImportError('Gagal mengurai dokumen Word: ' + err.message);
            setFileLoading(false);
          }
        };
        reader.onerror = () => {
          setImportError('Gagal membaca file .docx.');
          setFileLoading(false);
        };
        reader.readAsArrayBuffer(file);
      } else if (fileExtension === 'pdf') {
        setFileLoading(false);
        setImportError(
          'File PDF dideteksi. Demi keakuratan ekstrasi karakter terformat, silakan klik Copy (Salin) seluruh isi PDF Anda lalu Tempel (Paste) teks tersebut langsung ke editor di bawah ini.'
        );
      } else {
        setFileLoading(false);
        setImportError('Format file tidak didukung. Silakan gunakan Word (.docx) atau berkas Teks (.txt).');
      }
    } catch (err: any) {
      setImportError('Error membaca file: ' + err.message);
      setFileLoading(false);
    }
  };

  // call server-side node parse endpoint with file content
  const handleAiParse = async () => {
    if (!rawText.trim()) {
       setImportError('Silakan tempel draf naskah soal perawat ke kolom editor, atau unggah file Word/TXT di atas.');
       return;
    }
    
    setAiLoading(true);
    setImportError('');
    setParsedQuestions([]);
    
    try {
      const response = await fetch('/api/parse-questions', {
         method: 'POST',
         headers: { 'Content-Type': 'application/json' },
         body: JSON.stringify({ textContent: rawText, originalFileName: importFileName })
      });

      if (!response.ok) {
         throw new Error('Sistem gagal mengekstrak draft teks. Periksa konfigurasi API Key atau jaringan Anda.');
      }

      const data = await response.json();
      
      if (data && data.success && Array.isArray(data.questions)) {
         setParsedQuestions(data.questions);
         setSuccess(`AI Berhasil menyortir & mendeteksi ${data.questions.length} butir soal dari dokumen!`);
      } else {
         setImportError('Hasil parser AI tidak sejalan dengan skema. Silakan ulangi dengan teks yang lebih komplit.');
      }
    } catch (err: any) {
      setImportError(err?.message || 'Gagal tersambung dengan asisten AI.');
    } finally {
      setAiLoading(false);
    }
  };

  // Edit inline questions parsed state
  const startEditParsedQuestion = (index: number) => {
    const q = parsedQuestions[index];
    setEditingParsedIndex(index);
    setEditQCategory(q.category);
    setEditQText(q.question);
    setEditQOptionA(q.optionA);
    setEditQOptionB(q.optionB);
    setEditQOptionC(q.optionC);
    setEditQOptionD(q.optionD);
    setEditQOptionE(q.optionE);
    setEditQCorrectAnswer(q.correctAnswer);
    setEditQExplanation(q.explanation);
  };

  const saveEditedParsedQuestion = (index: number) => {
    const updated = [...parsedQuestions];
    updated[index] = {
      ...updated[index],
      category: editQCategory,
      question: editQText,
      optionA: editQOptionA,
      optionB: editQOptionB,
      optionC: editQOptionC,
      optionD: editQOptionD,
      optionE: editQOptionE,
      correctAnswer: editQCorrectAnswer,
      explanation: editQExplanation
    };
    setParsedQuestions(updated);
    setEditingParsedIndex(null);
  };

  const deleteParsedQuestion = (index: number) => {
    setParsedQuestions(prev => prev.filter((_, i) => i !== index));
  };

  // Batch import questions to actual App Database
  const commitBatchImport = async () => {
    if (parsedQuestions.length === 0) return;

    const finalTargetModel = showCustomModelInput ? customModelName.trim() : selectedModel;
    if (showCustomModelInput && !customModelName.trim()) {
      alert('Nama Model baru tidak boleh kosong!');
      return;
    }

    try {
      for (const q of parsedQuestions) {
        const fullQuestion: Question = {
          ...q,
          id: `q-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
          model: finalTargetModel || 'Model 1',
          createdAt: new Date().toISOString()
        };
        await addQuestion(fullQuestion);
      }

      setParsedQuestions([]);
      setRawText('');
      setImportFileName('');
      setSuccess(`Selamat! Berhasil mengimpor massal ${parsedQuestions.length} soal ke Paket "${finalTargetModel}"!`);
      setActiveFormTab('list');
      setModelFilter(finalTargetModel);
      setTimeout(() => setSuccess(''), 4500);
    } catch (err: any) {
      alert('Gagal saat memproses batch simpan: ' + err.message);
    }
  };

  // Filter list
  const filteredQuestions = questions.filter((q) => {
    const matchesSearch = q.question.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter ? q.category === categoryFilter : true;
    
    // Model filter (default Model 1 if not set)
    const qModel = q.model || 'Model 1';
    const matchesModel = modelFilter ? qModel === modelFilter : true;

    return matchesSearch && matchesCategory && matchesModel;
  });

  return (
    <div className="space-y-6 pb-12">
      
      {/* Title block */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <h2 className="font-display text-xl font-extrabold flex items-center gap-2">
             <BookOpen className="w-5 h-5 text-emerald-500" /> Bank Soal Paket CBT
          </h2>
          <p className="text-xs text-slate-400">Arsip bank soal tryout berdasarkan Model 1, Model 2 (Target 180 soal) dengan metode Import File PDF/Word.</p>
        </div>

        {/* Form switcher */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-950/80 rounded-xl">
           <button
              onClick={() => setActiveFormTab('list')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                activeFormTab === 'list' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500'
              }`}
           >
              Semua Soal
           </button>
           <button
              onClick={() => { resetManualForm(); setActiveFormTab('manual'); }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                activeFormTab === 'manual' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500'
              }`}
           >
              + Input Manual
           </button>
           <button
              onClick={() => { setImportError(''); setActiveFormTab('ai'); }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                activeFormTab === 'ai' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500'
              }`}
           >
              📥 Import PDF & Word (.docx)
           </button>
        </div>
      </div>

      {success && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/25 border border-emerald-100 dark:border-emerald-900/35 text-emerald-600 dark:text-emerald-400 text-xs rounded-xl flex items-center gap-2 shadow-sm animate-in fade-in duration-300">
           <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" /> <span className="font-semibold">{success}</span>
        </div>
      )}

      {/* STATS AREA: PROGRESS BAR SETIAP MODEL (TARGET 180 SOAL) */}
      <div className="bg-slate-50 dark:bg-slate-950/40 p-5 rounded-2xl border border-slate-150 dark:border-slate-800/80">
         <div className="flex items-center gap-2 mb-4">
            <Layers className="w-4 h-4 text-emerald-500" />
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-350">Status Kesiapan Paket Tryout (Model 1, 2, 3...)</h4>
         </div>
         <div className="grid md:grid-cols-3 gap-6">
            {models.map((mName) => {
               const { count, target, percentage } = getModelStats(mName);
               return (
                  <div key={mName} className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-2">
                     <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-800 dark:text-slate-200">{mName}</span>
                        <span className="font-mono text-[11px] text-slate-550 dark:text-slate-400">
                           <strong className="text-slate-900 dark:text-white">{count}</strong> / {target} Soal
                        </span>
                     </div>
                     <div className="h-2 w-full bg-slate-100 dark:bg-slate-950 rounded-full overflow-hidden">
                        <div 
                           className={`h-full rounded-full transition-all duration-500 ${
                              percentage >= 100 
                              ? 'bg-emerald-500' 
                              : percentage >= 50 
                              ? 'bg-amber-500' 
                              : 'bg-rose-500'
                           }`}
                           style={{ width: `${percentage}%` }}
                        />
                     </div>
                     <p className="text-[10px] text-slate-400 text-right">
                        {percentage}% Terpenuhi
                     </p>
                  </div>
               );
            })}
         </div>
      </div>

      {/* VIEW 1: QUESTIONS LISTING */}
      {activeFormTab === 'list' && (
        <div className="space-y-4">
           {/* Filters panel */}
           <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 items-center">
             <div className="relative">
                 <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                    <Search className="w-4 h-4" />
                 </span>
                 <input 
                    type="text"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    placeholder="Cari kata kunci vignette..."
                    className="w-full pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border text-xs rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                 />
             </div>

             <div>
                <select
                   value={categoryFilter}
                   onChange={e => setCategoryFilter(e.target.value)}
                   className="w-full px-4 py-2 bg-white dark:bg-slate-900 border text-xs rounded-xl text-slate-600 focus:outline-none"
                >
                   <option value="">Semua Departemen</option>
                   {categories.map((cat, idx) => (
                     <option key={idx} value={cat}>{cat}</option>
                   ))}
                </select>
             </div>

             <div>
                <select
                   value={modelFilter}
                   onChange={e => setModelFilter(e.target.value)}
                   className="w-full px-4 py-2 bg-white dark:bg-slate-900 border text-xs rounded-xl text-slate-600 focus:outline-none font-bold"
                >
                   <option value="">Semua Model Paket Tryout</option>
                   {models.map((md, idx) => (
                     <option key={idx} value={md}>{md}</option>
                   ))}
                </select>
             </div>

             <div className="text-right text-xs text-slate-400 font-semibold py-1">
                Total hasil Cocok: {filteredQuestions.length} Soal
             </div>
           </div>

           {/* Table listing */}
           <div className="bg-white dark:bg-slate-900 border border-slate-150 rounded-3xl overflow-hidden shadow-sm">
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredQuestions.length === 0 ? (
                  <p className="text-center py-12 text-xs text-slate-400">Belum ada soal dengan kecocokan filter tersebut.</p>
                ) : (
                  filteredQuestions.map((q) => (
                    <div key={q.id} className="p-5 flex items-start justify-between gap-4 hover:bg-slate-50/40 dark:hover:bg-slate-950/10 transition-colors group">
                       <div className="space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                             <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide bg-slate-100 dark:bg-slate-950 text-slate-500">{q.category}</span>
                             <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-50 dark:bg-emerald-950 text-emerald-600 border border-emerald-100 dark:border-emerald-900/30">
                                {q.model || 'Model 1'}
                             </span>
                          </div>
                          <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-100 leading-relaxed font-normal whitespace-pre-wrap max-h-16 overflow-hidden text-ellipsis line-clamp-2 select-text">{q.question}</p>
                          <div className="text-[10px] text-slate-400 font-semibold flex items-center gap-4">
                             <span>Opsi: {q.optionA ? "A s/d E Komplit" : "Belum diisi"}</span>
                             <span>Kunci Jawaban: <b className="text-emerald-500">{q.correctAnswer}</b></span>
                             {q.explanation && <span className="text-[9px] text-emerald-600">✓ Rationale Terlampir</span>}
                          </div>
                       </div>
                       
                       <button
                          onClick={() => {
                            if (confirm('Yakin ingin menghapus soal ini dari bank data?')) {
                              deleteQuestion(q.id);
                            }
                          }}
                          className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 dark:hover:bg-rose-950/30 rounded-lg transition-colors cursor-pointer"
                          title="Hapus Pertanyaan"
                       >
                          <Trash className="w-4 h-4" />
                       </button>
                    </div>
                  ))
                )}
              </div>
           </div>
        </div>
      )}

      {/* VIEW 2: MANUAL FORM INPUT */}
      {activeFormTab === 'manual' && (
        <form onSubmit={handleSaveQuestion} className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-150 dark:border-slate-800 shadow-sm space-y-6">
           <h3 className="font-display font-bold text-sm">Input Soal Vignette Perawat</h3>

           {/* Model Packet selector */}
           <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-150 dark:border-slate-850 space-y-3">
              <div className="flex items-center justify-between">
                 <label className="text-xs font-bold text-slate-600 dark:text-slate-350">Masukkan ke Paket Model:</label>
                 <button
                    type="button"
                    onClick={() => {
                      setShowCustomModelInput(!showCustomModelInput);
                      setCustomModelName('');
                    }}
                    className="text-xs font-extrabold text-emerald-600 hover:underline inline-flex items-center gap-1 cursor-pointer"
                 >
                    {showCustomModelInput ? "← Pilih Model Eksis" : "+ Buat Model Baru..."}
                 </button>
              </div>

              {showCustomModelInput ? (
                 <div className="space-y-1">
                    <span className="text-[10px] text-slate-450 dark:text-slate-550 font-semibold">Tulis Nama Model Baru (Contoh: "Model 3" atau "Paket Khusus")</span>
                    <input 
                       type="text"
                       value={customModelName}
                       onChange={e => setCustomModelName(e.target.value)}
                       placeholder="Misal: Model 3"
                       className="w-full px-4 py-2 bg-white dark:bg-slate-900 border text-xs rounded-xl text-slate-800 dark:text-white"
                    />
                 </div>
              ) : (
                 <select
                    value={selectedModel}
                    onChange={e => setSelectedModel(e.target.value)}
                    className="w-full px-4 py-2 bg-white dark:bg-slate-900 border text-xs rounded-xl font-bold text-slate-700 dark:text-slate-300"
                 >
                    <option value="Model 1">Model 1 (Default)</option>
                    <option value="Model 2">Model 2</option>
                    <option value="Model 3">Model 3</option>
                    {detectedModels.filter(m => m !== 'Model 1' && m !== 'Model 2' && m !== 'Model 3').map(m => (
                       <option key={m} value={m}>{m}</option>
                    ))}
                 </select>
              )}
           </div>

           {/* Row 1 */}
           <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                 <label className="text-xs font-semibold text-slate-400">Kategori Departemen</label>
                 <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl"
                 >
                    <option value="Keperawatan Medikal Bedah (KMB)">Keperawatan Medikal Bedah (KMB)</option>
                    <option value="Keperawatan Anak">Keperawatan Anak</option>
                    <option value="Keperawatan Maternitas">Keperawatan Maternitas</option>
                    <option value="Keperawatan Jiwa">Keperawatan Jiwa</option>
                    <option value="Keperawatan Keluarga">Keperawatan Keluarga</option>
                    <option value="Keperawatan Gerontik">Keperawatan Gerontik</option>
                    <option value="Keperawatan Gawat Darurat & Kritis">Keperawatan Gawat Darurat & Kritis</option>
                    <option value="Manajemen Keperawatan">Manajemen Keperawatan</option>
                 </select>
              </div>

              <div className="space-y-1">
                 <label className="text-xs font-semibold text-slate-400">Gambar Ilustrasi URL (Opsional)</label>
                 <input 
                    type="text"
                    value={imageUrl}
                    onChange={e => setImageUrl(e.target.value)}
                    placeholder="https://..."
                    className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl"
                 />
              </div>
           </div>

           {/* Narrative case */}
           <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-400">Kasus Kasus / Vignette Soal</label>
              <textarea 
                 rows={4}
                 required
                 value={questionText}
                 onChange={e => setQuestionText(e.target.value)}
                 placeholder="Seorang laki-laki berusia 45 tahun dirawat di ruang bedah dengan keluhan..."
                 className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-550"
              />
           </div>

           {/* A to E values */}
           <div className="space-y-3.5 border-t border-slate-100 dark:border-slate-800/80 pt-4">
              <p className="text-xs font-bold text-slate-400">Opsi Pilihan Ganda (A s/d E)</p>
              
              <div className="grid sm:grid-cols-2 gap-4">
                 <div className="space-y-1">
                    <span className="text-xs font-semibold text-slate-400">Opsi A</span>
                    <input type="text" value={optionA} onChange={e => setOptionA(e.target.value)} placeholder="Tindakan A" className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl" />
                 </div>
                 <div className="space-y-1">
                    <span className="text-xs font-semibold text-slate-400">Opsi B</span>
                    <input type="text" value={optionB} onChange={e => setOptionB(e.target.value)} placeholder="Tindakan B" className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl" />
                 </div>
                 <div className="space-y-1">
                    <span className="text-xs font-semibold text-slate-400">Opsi C</span>
                    <input type="text" value={optionC} onChange={e => setOptionC(e.target.value)} placeholder="Tindakan C" className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl" />
                 </div>
                 <div className="space-y-1">
                    <span className="text-xs font-semibold text-slate-400">Opsi D</span>
                    <input type="text" value={optionD} onChange={e => setOptionD(e.target.value)} placeholder="Tindakan D" className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl" />
                 </div>
                 <div className="space-y-1">
                    <span className="text-xs font-semibold text-slate-400">Opsi E</span>
                    <input type="text" value={optionE} onChange={e => setOptionE(e.target.value)} placeholder="Tindakan E" className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl" />
                 </div>

                 {/* Key */}
                 <div className="space-y-1">
                    <span className="text-xs font-semibold text-slate-400 font-bold">Kunci Jawaban</span>
                    <select
                       value={correctAnswer}
                       onChange={e => setCorrectAnswer(e.target.value)}
                       className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border border-emerald-500/20 text-xs rounded-xl font-bold text-emerald-600"
                    >
                       <option value="A">A</option>
                       <option value="B">B</option>
                       <option value="C">C</option>
                       <option value="D">D</option>
                       <option value="E">E</option>
                    </select>
                 </div>
              </div>
           </div>

           {/* Rationale explanation text */}
           <div className="space-y-1 border-t border-slate-100 dark:border-slate-800/80 pt-4">
              <label className="text-xs font-semibold text-slate-400">Pembahasan Rationalisasi Medis / Hasil Diagnosa</label>
              <textarea 
                 rows={3}
                 value={explanation}
                 onChange={e => setExplanation(e.target.value)}
                 placeholder="Kunci jawaban tepat karena intervensi pertama wajib melancarkan jalan nafas..."
                 className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl"
              />
           </div>

           <button
              type="submit"
              className="py-3 px-8 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white rounded-xl text-xs font-bold pt-3.5 shadow-md active:scale-95 cursor-pointer"
           >
              Simpan Soal ke Bank Data
           </button>
        </form>
      )}

      {/* VIEW 3: FILE IMPORT MANAGER & GEMINI AI PARSER */}
      {activeFormTab === 'ai' && (
         <div className="space-y-6">
            <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-150 dark:border-slate-800 shadow-sm space-y-6">
               <div className="space-y-1.5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                     <h3 className="font-display font-extrabold text-sm flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-emerald-500 animate-pulse" /> Gemini AI Naskah & File Importer
                     </h3>
                     <p className="text-xs text-slate-400">Unggah berkas Word (.docx) / Text (.txt) secara langsung, atau tempelkan draf soal perawat untuk dibedah otomatis.</p>
                  </div>
                  
                  {/* Select Destination Model */}
                  <div className="bg-slate-50 dark:bg-slate-950/60 p-2.5 rounded-xl border border-slate-200/45 dark:border-slate-800 text-[11px] font-semibold space-y-1">
                     <div className="flex justify-between gap-4">
                        <span className="text-slate-500">Tujuan Impor Model Packet:</span>
                        <button 
                           type="button" 
                           onClick={() => setShowCustomModelInput(!showCustomModelInput)}
                           className="text-emerald-600 font-extrabold hover:underline cursor-pointer"
                        >
                           {showCustomModelInput ? "Eksis" : "+ Model Baru"}
                        </button>
                     </div>
                     {showCustomModelInput ? (
                        <input
                           type="text"
                           value={customModelName}
                           onChange={e => setCustomModelName(e.target.value)}
                           placeholder="Ex: Model 2"
                           className="px-2 py-1 border rounded bg-white dark:bg-slate-900 text-xs w-44 mt-1 font-bold text-slate-800 dark:text-white"
                        />
                     ) : (
                        <select
                           value={selectedModel}
                           onChange={e => setSelectedModel(e.target.value)}
                           className="px-2 py-1 rounded bg-white dark:bg-slate-900 border font-bold text-[11px] text-slate-700 dark:text-slate-300 w-44 mt-1 cursor-pointer"
                        >
                           <option value="Model 1">Model 1 (Default)</option>
                           <option value="Model 2">Model 2</option>
                           <option value="Model 3">Model 3</option>
                           {detectedModels.filter(m => m !== 'Model 1' && m !== 'Model 2' && m !== 'Model 3').map(m => (
                              <option key={m} value={m}>{m}</option>
                           ))}
                        </select>
                     )}
                  </div>
               </div>

               {importError && (
                  <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/25 border border-rose-100 dark:border-rose-900/40 text-rose-600 dark:text-rose-400 text-xs flex items-start gap-2 animate-shake">
                     <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                     <span className="font-medium whitespace-pre-wrap">{importError}</span>
                  </div>
               )}

               {/* Import Upload Dropzone */}
               <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="p-8 border-2 border-dashed border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 rounded-2xl cursor-pointer text-center space-y-2 bg-slate-50/50 dark:bg-slate-950/20 hover:bg-emerald-50/5 dark:hover:bg-emerald-950/5 transition-all group"
               >
                  <input 
                     type="file"
                     ref={fileInputRef}
                     onChange={handleFileChange}
                     accept=".txt,.docx,.doc"
                     className="hidden"
                  />
                  <div className="mx-auto w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-900 flex items-center justify-center text-slate-400 group-hover:bg-emerald-100/50 dark:group-hover:bg-emerald-950/50 group-hover:text-emerald-500 transition-colors">
                     <UploadCloud className="w-6 h-6" />
                  </div>
                  <div>
                     <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                        {fileLoading ? "Mengekstrak berkas..." : importFileName ? `Berkas terpilih: ${importFileName}` : "Klik / Seret File Word (.docx) atau Text (.txt) di sini"}
                     </p>
                     <p className="text-[10px] text-slate-400">Kami akan mengekstrak kalimat-kalimat vignettes agar siap diproses AI secara langsung</p>
                  </div>
               </div>

               {/* Text editor paste block */}
               <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-medium">
                     <label className="text-slate-400">Isi Naskah Soal (Hasil Ekstraksi Dokumen / Manual Paste)</label>
                     {rawText.length > 0 && (
                        <button 
                           onClick={() => setRawText('')}
                           className="text-slate-400 hover:text-rose-500 text-[10px]"
                        >
                           Bersihkan Editor
                        </button>
                     )}
                  </div>
                  
                  <textarea
                     rows={8}
                     value={rawText}
                     onChange={e => setRawText(e.target.value)}
                     placeholder="Format Bebas: Salin vignette soal Word / PDF ke sini.
Format ideal:
Soal 1. Seorang pria dirawat dengan fraktur femur...
A. Pasang bidai
B. Reduksi terbuka
C. Traksi
D. Kolaborasi analgetik
E. Fisioterapi
Kunci: C
Pembahasan: Traksi berguna untuk meminimalkan spasme otot..."
                     className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 border text-xs rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 leading-relaxed font-mono"
                  />
               </div>

               <div className="flex flex-col sm:flex-row gap-4 justify-between border-t border-slate-105 dark:border-slate-850 pt-4">
                  <div className="text-[10px] text-slate-450 dark:text-slate-500 max-w-sm flex items-center gap-1">
                     <HelpCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                     <span>Gemini AI akan mendeteksi opsi A/B/C/D/E, Kategori departemen medis, dan menyusun rationale otomatis.</span>
                  </div>

                  <button
                     onClick={handleAiParse}
                     disabled={aiLoading || !rawText.trim()}
                     className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 text-xs font-bold flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50 transition-all pt-3.5 cursor-pointer shadow-sm hover:shadow"
                  >
                     <Sparkles className="w-4 h-4 text-emerald-400" />
                     {aiLoading ? "Gemini sedang mem-bedah naskah..." : "Picu Ekstraksi Gemini AI"}
                  </button>
               </div>
            </div>

            {/* PREVIEW & COMMITTING SCREEN POST PARSING */}
            {parsedQuestions.length > 0 && (
               <div className="space-y-4 animate-in slide-in-from-bottom-4 duration-300">
                  <div className="p-4 bg-emerald-50/70 dark:bg-emerald-950/25 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                     <div>
                        <h4 className="font-extrabold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                           <Check className="w-5 h-5 text-emerald-555" />
                           Review Hasil Ekstrasi AI ({parsedQuestions.length} Soal Teridentifikasi)
                        </h4>
                        <p className="text-xs text-slate-500">Silakan tinjau keakuratan, lakukan koreksi bila perlu sebelum mem-publish ke Database.</p>
                     </div>

                     <div className="flex items-center gap-3">
                        <button 
                           onClick={() => {
                              if (confirm('Batal impor dan bersihkan list preview?')) {
                                 setParsedQuestions([]);
                              }
                           }}
                           className="px-3 py-2 border rounded-xl hover:bg-slate-50 dark:hover:bg-slate-900 text-xs font-bold text-slate-500 cursor-pointer"
                        >
                           Batal
                        </button>

                        <button
                           onClick={commitBatchImport}
                           className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow active:scale-95 pt-2.5"
                        >
                           <Save className="w-4 h-4" />
                           Konfirmasi Simpan ke Paket "{showCustomModelInput ? customModelName : selectedModel}"
                        </button>
                     </div>
                  </div>

                  <div className="space-y-4">
                     {parsedQuestions.map((pq, idx) => {
                        const isEditingThis = editingParsedIndex === idx;
                        return (
                           <div key={idx} className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800/80 pb-3">
                                 <span className="text-[10px] font-black uppercase text-slate-400">Butir Soal #{idx + 1}</span>
                                 
                                 <div className="flex items-center gap-2">
                                    {isEditingThis ? (
                                       <>
                                          <button 
                                             onClick={() => saveEditedParsedQuestion(idx)}
                                             className="px-2.5 py-1 bg-emerald-500 text-white rounded-lg text-[10px] font-black cursor-pointer flex items-center gap-1"
                                          >
                                             <Check className="w-3 h-3" /> Simpan Perubahan
                                          </button>
                                          <button 
                                             onClick={() => setEditingParsedIndex(null)}
                                             className="px-2 py-1 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-lg text-[10px] font-semibold cursor-pointer"
                                          >
                                             Batal
                                          </button>
                                       </>
                                    ) : (
                                       <>
                                          <button 
                                             onClick={() => startEditParsedQuestion(idx)}
                                             className="p-1 hover:bg-slate-100 dark:hover:bg-slate-850 rounded text-slate-450 hover:text-slate-800 flex items-center gap-1 text-[10px] font-bold cursor-pointer"
                                          >
                                             <Edit3 className="w-3.5 h-3.5" /> Edit
                                          </button>
                                          <button 
                                             onClick={() => deleteParsedQuestion(idx)}
                                             className="p-1 hover:bg-rose-50 text-slate-405 hover:text-rose-600 rounded cursor-pointer"
                                             title="Jangan sertakan soal ini"
                                          >
                                             <Trash className="w-3.5 h-3.5" />
                                          </button>
                                       </>
                                    )}
                                 </div>
                              </div>

                              {isEditingThis ? (
                                 <div className="space-y-4 text-xs">
                                    <div className="grid grid-cols-2 gap-4">
                                       <div className="space-y-1">
                                          <span className="font-bold text-slate-400">Kategori Departemen</span>
                                          <select 
                                             value={editQCategory}
                                             onChange={e => setEditQCategory(e.target.value)}
                                             className="w-full px-2.5 py-1.5 border rounded-lg bg-slate-50 dark:bg-slate-950 font-medium"
                                          >
                                             <option value="Keperawatan Medikal Bedah (KMB)">Keperawatan Medikal Bedah (KMB)</option>
                                             <option value="Keperawatan Anak">Keperawatan Anak</option>
                                             <option value="Keperawatan Maternitas">Keperawatan Maternitas</option>
                                             <option value="Keperawatan Jiwa">Keperawatan Jiwa</option>
                                             <option value="Keperawatan Keluarga">Keperawatan Keluarga</option>
                                             <option value="Keperawatan Gerontik">Keperawatan Gerontik</option>
                                             <option value="Keperawatan Gawat Darurat & Kritis">Keperawatan Gawat Darurat & Kritis</option>
                                             <option value="Manajemen Keperawatan">Manajemen Keperawatan</option>
                                          </select>
                                       </div>
                                       
                                       <div className="space-y-1">
                                          <span className="font-bold text-slate-400">Kunci</span>
                                          <select 
                                             value={editQCorrectAnswer}
                                             onChange={e => setEditQCorrectAnswer(e.target.value as any)}
                                             className="w-full px-2.5 py-1.5 border rounded-lg bg-slate-50 dark:bg-slate-950 font-bold text-emerald-600"
                                          >
                                             <option value="A">A</option>
                                             <option value="B">B</option>
                                             <option value="C">C</option>
                                             <option value="D">D</option>
                                             <option value="E">E</option>
                                          </select>
                                       </div>
                                    </div>

                                    <div className="space-y-1">
                                       <span className="font-bold text-slate-400">Kasus / Vignette</span>
                                       <textarea 
                                          rows={3} 
                                          value={editQText}
                                          onChange={e => setEditQText(e.target.value)}
                                          className="w-full px-2.5 py-1.5 border rounded-lg bg-slate-50 dark:bg-slate-950"
                                       />
                                    </div>

                                    <div className="grid sm:grid-cols-2 gap-2 text-xs">
                                       <div className="flex gap-2 items-center">
                                          <span className="font-bold text-slate-400">A</span>
                                          <input type="text" value={editQOptionA} onChange={e => setEditQOptionA(e.target.value)} className="w-full border p-1 rounded bg-slate-50 dark:bg-slate-950" />
                                       </div>
                                       <div className="flex gap-2 items-center">
                                          <span className="font-bold text-slate-400">B</span>
                                          <input type="text" value={editQOptionB} onChange={e => setEditQOptionB(e.target.value)} className="w-full border p-1 rounded bg-slate-50 dark:bg-slate-950" />
                                       </div>
                                       <div className="flex gap-2 items-center">
                                          <span className="font-bold text-slate-400">C</span>
                                          <input type="text" value={editQOptionC} onChange={e => setEditQOptionC(e.target.value)} className="w-full border p-1 rounded bg-slate-50 dark:bg-slate-950" />
                                       </div>
                                       <div className="flex gap-2 items-center">
                                          <span className="font-bold text-slate-400">D</span>
                                          <input type="text" value={editQOptionD} onChange={e => setEditQOptionD(e.target.value)} className="w-full border p-1 rounded bg-slate-50 dark:bg-slate-950" />
                                       </div>
                                       <div className="flex gap-2 items-center">
                                          <span className="font-bold text-slate-400">E</span>
                                          <input type="text" value={editQOptionE} onChange={e => setEditQOptionE(e.target.value)} className="w-full border p-1 rounded bg-slate-50 dark:bg-slate-950" />
                                       </div>
                                    </div>

                                    <div className="space-y-1">
                                       <span className="font-bold text-slate-400">Pembahasan / Rationale</span>
                                       <textarea 
                                          rows={2} 
                                          value={editQExplanation}
                                          onChange={e => setEditQExplanation(e.target.value)}
                                          className="w-full px-2.5 py-1.5 border rounded-lg bg-slate-50 dark:bg-slate-950"
                                       />
                                    </div>
                                 </div>
                              ) : (
                                 <div className="space-y-3">
                                    <div className="flex items-center gap-2">
                                       <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400 border border-indigo-150/40">{pq.category}</span>
                                       <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 dark:bg-amber-950 text-amber-600">Terdeteksi Kunci {pq.correctAnswer}</span>
                                    </div>

                                    <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-100 font-normal leading-relaxed">{pq.question}</p>

                                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2 text-xs">
                                       <div className={`p-2 rounded border border-slate-100 dark:border-slate-850 bg-slate-50/50 ${(pq.correctAnswer === 'A') ? "border-emerald-500 bg-emerald-50/10 dark:bg-emerald-950/10" : ""}`}>
                                          <strong className="text-[10px] mr-1">Option A:</strong>{pq.optionA}
                                       </div>
                                       <div className={`p-2 rounded border border-slate-100 dark:border-slate-850 bg-slate-50/50 ${(pq.correctAnswer === 'B') ? "border-emerald-500 bg-emerald-50/10 dark:bg-emerald-950/10" : ""}`}>
                                          <strong className="text-[10px] mr-1">Option B:</strong>{pq.optionB}
                                       </div>
                                       <div className={`p-2 rounded border border-slate-100 dark:border-slate-850 bg-slate-50/50 ${(pq.correctAnswer === 'C') ? "border-emerald-500 bg-emerald-50/10 dark:bg-emerald-950/10" : ""}`}>
                                          <strong className="text-[10px] mr-1">Option C:</strong>{pq.optionC}
                                       </div>
                                       <div className={`p-2 rounded border border-slate-100 dark:border-slate-850 bg-slate-50/50 ${(pq.correctAnswer === 'D') ? "border-emerald-500 bg-emerald-50/10 dark:bg-emerald-950/10" : ""}`}>
                                          <strong className="text-[10px] mr-1">Option D:</strong>{pq.optionD}
                                       </div>
                                       <div className={`p-2 rounded border border-slate-100 dark:border-slate-850 bg-slate-50/50 ${(pq.correctAnswer === 'E') ? "border-emerald-500 bg-emerald-50/10 dark:bg-emerald-950/10" : ""}`}>
                                          <strong className="text-[10px] mr-1">Option E:</strong>{pq.optionE}
                                       </div>
                                    </div>

                                    {pq.explanation && (
                                       <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs space-y-1 text-slate-500 dark:text-slate-450 border border-slate-100 dark:border-slate-850">
                                          <p className="font-extrabold text-[10px] text-slate-400 flex items-center gap-1">🔎 Rationale Pembahasan Medis:</p>
                                          <p className="leading-relaxed">{pq.explanation}</p>
                                       </div>
                                    )}
                                 </div>
                              )}
                           </div>
                        );
                     })}
                  </div>

                  {/* Bottom Commit Block bar */}
                  <div className="p-4 bg-slate-900 rounded-2xl flex items-center justify-between text-white border border-slate-800 shadow-xl">
                     <div className="space-y-0.5">
                        <p className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                           <Check className="w-4 h-4" /> Finalisasi Batch Impor
                        </p>
                        <p className="text-[10px] text-slate-400">Luncurkan {parsedQuestions.length} soal ke bank naskah "{showCustomModelInput ? customModelName : selectedModel}"</p>
                     </div>
                     <button
                        onClick={commitBatchImport}
                        className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-xs transition-colors active:scale-95 cursor-pointer pt-2.5 shadow"
                     >
                        Impor Masal {parsedQuestions.length} Soal Ke Database
                     </button>
                  </div>
               </div>
            )}
         </div>
      )}

    </div>
  );
}
