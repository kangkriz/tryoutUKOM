import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Award, Clock, BookOpen, AlertCircle, PlayCircle, ClipboardList, Info, Calendar } from 'lucide-react';
import { Question } from '../types';

interface ParticipantProps {
  onStartExam: (questionsCount: number, category?: string, model?: string) => void;
  onNavigatePage: (page: string) => void;
}

export default function ParticipantDashboard({ onStartExam, onNavigatePage }: ParticipantProps) {
  const { currentUser, questions, results, announcements, kisiKisi } = useApp();
  const [showConfig, setShowConfig] = useState(false);
  const [examSize, setExamSize] = useState<number>(180); // default to full 180 questions
  const [selectedSub, setSelectedSub] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState<string>('Model 1');

  // Calculate student performance
  const studentResults = results.filter(r => r.userId === currentUser?.id);
  const totalExams = studentResults.length;
  const averageScore = totalExams > 0 
    ? parseFloat((studentResults.reduce((sum, r) => sum + r.score, 0) / totalExams).toFixed(1)) 
    : 0;
  
  const lastExam = studentResults[0]; // first item as sorted desc in results
  
  // Find Categories available
  const categories = Array.from(new Set(questions.map((q) => q.category)));

  // Find Models available
  const models = Array.from(new Set(questions.map((q) => q.model || 'Model 1')));

  // Calculate question count based on filters
  const availableQuestions = questions.filter(q => {
     const matchesCategory = selectedSub ? q.category === selectedSub : true;
     const matchesModel = selectedModel ? (q.model || 'Model 1') === selectedModel : true;
     return matchesCategory && matchesModel;
  });
  const questionsCount = availableQuestions.length;

  return (
    <div className="space-y-8 pb-12">
      {/* Welcome Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-500 text-white p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full translate-x-12 -translate-y-12" />
        <div className="absolute bottom-0 right-1/4 w-32 h-32 bg-white/5 rounded-full translate-y-12" />
        
        <div className="relative z-10 space-y-3 max-w-2xl">
          <div className="px-2.5 py-1 bg-white/20 rounded-full font-medium text-[11px] inline-flex items-center gap-1.5 uppercase tracking-wider backdrop-blur-md">
            🎓 Portal Mahasiswa D3 Keperawatan
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight">
            Selamat Belajar, {currentUser?.name || "Rekan Sejawat"}!
          </h2>
          <p className="text-emerald-50 text-sm leading-relaxed">
            Sukseskan Uji Kompetensi Nasional D3 Keperawatan Anda di sini. Latih retensi pemahaman vignettes klinis Anda dengan simulasi CAT riil.
          </p>
        </div>
      </div>

      {/* Stats Counter Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl text-emerald-600 dark:text-emerald-400">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <p className="text-10 text-slate-400 font-semibold tracking-wider uppercase">Skor Rata-Rata</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-slate-100">{averageScore}%</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-teal-50 dark:bg-teal-950/40 rounded-xl text-teal-600 dark:text-teal-400">
            <ClipboardList className="w-5 h-5" />
          </div>
          <div>
            <p className="text-10 text-slate-400 font-semibold tracking-wider uppercase">Latihan Selesai</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-slate-100">{totalExams} Kali</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-cyan-50 dark:bg-cyan-950/40 rounded-xl text-cyan-600 dark:text-cyan-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <p className="text-10 text-slate-400 font-semibold tracking-wider uppercase">Koleksi Soal</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-slate-100">{questions.length} Butir</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl text-amber-600 dark:text-amber-400">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-10 text-slate-400 font-semibold tracking-wider uppercase">Nilai Terakhir</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-slate-100">
              {lastExam ? `${lastExam.score}%` : "Belum Tes"}
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid: Launch Exam & News Notice */}
      <div className="grid lg:grid-cols-3 gap-8">
        
        {/* Launch Tryout Config Panel */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="space-y-1">
                <h3 className="font-display font-extrabold text-lg flex items-center gap-2">
                  <PlayCircle className="w-5 h-5 text-emerald-500" /> Simulasi Tryout CBT
                </h3>
                <p className="text-xs text-slate-400">Konfigurasi materi serta durasi sebelum memulai.</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid sm:grid-cols-3 gap-4">
                {/* Model Packet selection */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-400">Paket Model Tryout</label>
                  <select
                    value={selectedModel}
                    onChange={(e) => setSelectedModel(e.target.value)}
                    className="w-full h-[42px] px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-slate-700 dark:text-slate-300 cursor-pointer"
                  >
                    <option value="">Semua Model (Random Campuran)</option>
                    {models.filter(Boolean).map((m, idx) => (
                      <option key={idx} value={m}>{m}</option>
                    ))}
                  </select>
                </div>

                {/* Exam Size Option */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-400">Jumlah Soal Tryout</label>
                  <select
                    value={examSize}
                    onChange={(e) => setExamSize(Number(e.target.value))}
                    className="w-full h-[42px] px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-slate-700 dark:text-slate-350 cursor-pointer"
                  >
                    <option value={10}>10 Soal (Latihan Cepat)</option>
                    <option value={20}>20 Soal (Diagnostic)</option>
                    <option value={50}>50 Soal (Mini Tryout)</option>
                    <option value={100}>100 Soal (Simulasi Intensif)</option>
                    <option value={180}>180 Soal (Rekomendasi UKOM Asli)</option>
                    <option value={9999}>Maksimal Seluruh Soal ({questionsCount} Butir)</option>
                  </select>
                </div>

                {/* Categories subfield */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-400">Departemen Keperawatan</label>
                  <select
                    value={selectedSub}
                    onChange={(e) => setSelectedSub(e.target.value)}
                    className="w-full h-[42px] px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-slate-700 dark:text-slate-350 cursor-pointer"
                  >
                    <option value="">Semua Departemen (Random Campuran)</option>
                    {categories.filter(Boolean).map((cat, idx) => (
                      <option key={idx} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Live matching indicator */}
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 bg-slate-100/50 dark:bg-slate-950 p-2.5 rounded-lg border border-slate-100 dark:border-slate-850">
                 <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                 <span>Pilihan Model/Kategori saat ini memiliki: <strong className="text-slate-900 dark:text-white">{questionsCount} butir soal</strong> yang terdaftar dalam database.</span>
              </div>

              {/* CBT Warnings */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-850/80 text-xs text-slate-500 dark:text-slate-400 space-y-2">
                <p className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-emerald-500" /> Aturan Ujian CBT Keperawatan:
                </p>
                <ul className="list-disc pl-5 space-y-1 leading-relaxed">
                  <li>Durasi waktu dihitung 1 menit per soal secara proporsional.</li>
                  <li>Sistem auto-save mutakhir mengamankan jawaban Anda di cache setiap kali beralih nomor.</li>
                  <li>Ujian akan disubmit otomatis secara aman ketika penghitung waktu habis.</li>
                  <li>Disarankan masuk ke Fullscreen untuk melatih fokus penilaiaan.</li>
                </ul>
              </div>

              <button
                onClick={() => onStartExam(examSize, selectedSub || undefined, selectedModel || undefined)}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 text-white font-semibold text-sm shadow-lg shadow-emerald-500/10 hover:shadow-emerald-500/25 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                Let's Go! Mulai Simulasi Tryout CBT
              </button>
            </div>
          </div>

          {/* Quick learning card */}
          <div className="grid md:grid-cols-2 gap-4">
            <div
              onClick={() => onNavigatePage('kisiKisi')}
              className="p-5 bg-gradient-to-br from-indigo-50 to-indigo-100/30 dark:from-slate-900 dark:to-indigo-950/20 rounded-2xl border border-indigo-150/40 dark:border-slate-800 cursor-pointer hover:-translate-y-1 transition-all group"
            >
              <h4 className="font-display font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                📚 Kisi-Kisi Kompetensi <span className="group-hover:translate-x-1.5 transition-transform">→</span>
              </h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">Pelajari sebaran asuhan keperawatan 7 departemen penting UKOM AIPViKI nasional.</p>
            </div>

            <div
              onClick={() => onNavigatePage('history')}
              className="p-5 bg-gradient-to-br from-amber-50 to-amber-100/30 dark:from-slate-900 dark:to-amber-950/20 rounded-2xl border border-amber-150/40 dark:border-slate-800 cursor-pointer hover:-translate-y-1 transition-all group"
            >
              <h4 className="font-display font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                📊 Riwayat Tryout & Pembahasan <span className="group-hover:translate-x-1.5 transition-transform">→</span>
              </h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">Review kunci jawaban, skor akhir, statistik kelulusan, serta rasional keperawatan komplit.</p>
            </div>
          </div>
        </div>

        {/* Info Board Announcements Sidebar */}
        <div className="space-y-6">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="font-display font-bold text-base flex items-center gap-2">
              <Info className="w-5 h-5 text-emerald-500" /> Informasi Terbaru
            </h3>
            
            <div className="space-y-4 divide-y divide-slate-150/50 dark:divide-slate-800">
              {announcements.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">Belum ada pengumuman terbaru.</p>
              ) : (
                announcements.map((ann) => (
                  <div key={ann.id} className="pt-4 first:pt-0 space-y-2">
                    {ann.bannerUrl && (
                      <img
                        src={ann.bannerUrl}
                        alt="banner"
                        referrerPolicy="no-referrer"
                        className="w-full h-24 object-cover rounded-xl"
                      />
                    )}
                    <h4 className="font-bold text-xs leading-snug hover:text-emerald-500 transition-colors">{ann.title}</h4>
                    <p className="text-[11px] text-slate-450 dark:text-slate-400 leading-relaxed max-h-16 overflow-hidden text-ellipsis line-clamp-2">
                      {ann.content}
                    </p>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                      <Calendar className="w-3.5 h-3.5" />
                      {new Date(ann.createdAt).toLocaleDateString('id-ID')}
                    </div>
                  </div>
                ))
              )}
            </div>
            
            <button
              onClick={() => onNavigatePage('information')}
              className="w-full py-2.5 rounded-xl border border-slate-150 dark:border-slate-800 text-xs hover:bg-slate-50 dark:hover:bg-slate-950 font-semibold transition-colors mt-2"
            >
              Lihat Semua Informasi
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
