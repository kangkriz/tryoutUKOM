import { motion } from 'motion/react';
import { ShieldCheck, Calendar, BookOpen, Clock, Award, LogIn, Laptop, Smartphone, Users } from 'lucide-react';

interface LandingPageProps {
  onStartLogin: () => void;
}

export default function LandingPage({ onStartLogin }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-300">
      {/* Header Navigation */}
      <header className="fixed top-0 left-0 right-0 z-50 glassmorphism border-b border-slate-100 dark:border-slate-900 bg-white/80 dark:bg-slate-950/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden flex items-center justify-center p-0.5">
              <img
                src="https://iili.io/C25elun.jpg"
                alt="Logo"
                className="w-full h-full object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="font-display font-bold text-lg tracking-tight bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-500 bg-clip-text text-transparent">
              CBT Perawat D3
            </span>
          </div>
          <button
            onClick={onStartLogin}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 text-white font-medium shadow-md shadow-emerald-500/10 hover:shadow-emerald-500/25 active:scale-95 transition-all text-sm"
          >
            <LogIn className="w-4 h-4" /> Masuk Aplikasi
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-12">
        <div className="flex-1 text-center lg:text-left space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 font-medium text-xs border border-emerald-100 dark:border-emerald-900/30">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            Tryout Uji Kompetensi Perawat D3 Edisi 2026
          </div>
          
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight">
            Lulus UKOM D3 <br />
            <span className="bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-500 bg-clip-text text-transparent">
              Sekali Tes, Skor Sempurna!
            </span>
          </h1>

          <p className="text-slate-600 dark:text-slate-400 text-base sm:text-lg max-w-xl mx-auto lg:mx-0">
            Platform Computer Based Test (CBT) tercanggih khusus mahasiswa D3 Keperawatan. 
            Tampilan simulasi asli CAT UKOM, terstruktur sesuai kisi-kisi nasional terupdate.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start pt-4">
            <button
              onClick={onStartLogin}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 font-semibold shadow-xl active:scale-95 transition-all"
            >
              Mulai Ujian Sekarang
            </button>
            <button
              onClick={onStartLogin}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-white font-medium border border-slate-200 dark:border-slate-800 transition-all flex items-center justify-center gap-2"
            >
              Demo Admin CBT
            </button>
          </div>
        </div>

        {/* Hero Interactive App Device Frame */}
        <div className="flex-1 w-full max-w-md lg:max-w-none relative">
          <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/20 to-teal-500/10 blur-3xl -z-10 rounded-full" />
          
          <div className="glassmorphism rounded-3xl p-6 bg-white/75 dark:bg-slate-900/75 border border-slate-100 dark:border-slate-800 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-600 to-teal-500" />
            
            {/* Custom Interactive Floating Cards */}
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-4 border-b border-slate-100 dark:border-slate-800/80">
                <span className="font-display font-medium text-xs uppercase tracking-wider text-slate-400">Computer Based Test (CBT)</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-500 font-semibold">Live Timer: 180:00 Menit</span>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100/50 dark:border-slate-850">
                <p className="text-xs text-slate-400 font-medium mb-1.5">No. Soal 12 dari 180 (Keperawatan Jiwa)</p>
                <p className="text-sm font-medium leading-relaxed">
                  Seorang perempuan berusia 32 tahun menolak berinteraksi dengan orang lain, merasa dirinya tidak berharga...
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-emerald-500 text-white rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-500/20">
                  <Award className="w-4 h-4" />
                  <div>
                    <p className="font-semibold text-xs">Target Kelulusan</p>
                    <p className="opacity-90">Passing Grade 100%</p>
                  </div>
                </div>
                <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-500" />
                  <div>
                    <p className="font-bold">5.200+</p>
                    <p className="text-[10px] text-slate-400">Total Pengguna</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Stats Grid */}
      <section className="bg-white dark:bg-slate-900 border-y border-slate-100 dark:border-slate-800 py-12 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="text-center">
            <p className="font-display text-3xl sm:text-4xl font-extrabold text-emerald-600 dark:text-emerald-400">180</p>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">Soal Standar Nasional</p>
          </div>
          <div className="text-center">
            <p className="font-display text-3xl sm:text-4xl font-extrabold text-emerald-600 dark:text-emerald-400">180</p>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">Menit Waktu Simulasi</p>
          </div>
          <div className="text-center">
            <p className="font-display text-3xl sm:text-4xl font-extrabold text-emerald-600 dark:text-emerald-400">98.4%</p>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">Tingkat Kelulusan Alumni</p>
          </div>
          <div className="text-center">
            <p className="font-display text-3xl sm:text-4xl font-extrabold text-emerald-600 dark:text-emerald-400">100%</p>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">Tryout Realtime CAT</p>
          </div>
        </div>
      </section>

      {/* Features Showcase */}
      <section className="py-20 px-4 max-w-7xl mx-auto space-y-16">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <h2 className="font-display text-3xl font-extrabold">Mengapa Memilih Platform Kami?</h2>
          <p className="text-slate-500 dark:text-slate-400">Satu-satunya sistem pembelajaran UKOM D3 dengan kesesuaian blueprint kurikulum AIPViKI terlengkap.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="p-6 bg-white dark:bg-slate-900/40 rounded-2xl border border-slate-100 dark:border-slate-800/80 flex flex-col items-start gap-4 hover:-translate-y-1.5 transition-transform duration-350">
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 rounded-xl text-emerald-600">
              <Laptop className="w-6 h-6" />
            </div>
            <h3 className="font-display font-bold text-lg">Responsif Multi-Device</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
              Didesain optimal untuk PC/Komputer, Tablet, maupun HP Android/iPhone. Belajar bebas kapan saja dan di mana saja.
            </p>
          </div>

          <div className="p-6 bg-white dark:bg-slate-900/40 rounded-2xl border border-slate-100 dark:border-slate-800/80 flex flex-col items-start gap-4 hover:-translate-y-1.5 transition-transform duration-350">
            <div className="p-3 bg-cyan-50 dark:bg-cyan-950/50 rounded-xl text-cyan-600">
              <BookOpen className="w-6 h-6" />
            </div>
            <h3 className="font-display font-bold text-lg">Kupas Pembahasan Detail</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
              Materi pembahasan komplit disertai rasionalisasi ilmiah perawat profesional di setiap akhir tryout.
            </p>
          </div>

          <div className="p-6 bg-white dark:bg-slate-900/40 rounded-2xl border border-slate-100 dark:border-slate-800/80 flex flex-col items-start gap-4 hover:-translate-y-1.5 transition-transform duration-350">
            <div className="p-3 bg-indigo-50 dark:bg-indigo-950/50 rounded-xl text-indigo-600">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="font-display font-bold text-lg">Waktu Riil & Anti-Gagal</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
              Penghitung mundur otomatis di atas layar. Auto-save tangguh yang menjamin progres jawaban tersimpan aman walaupun jaringan mati.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800 text-center">
        <p className="text-sm">&copy; 2026 Tryout Uji Kompetensi Perawat D3. All rights reserved.</p>
        <p className="text-[11px] opacity-60 mt-2">Dibuat khusus untuk persiapan ujian mandiri dengan sistem CAT Premium AIPViKI.</p>
      </footer>
    </div>
  );
}
