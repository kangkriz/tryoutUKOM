import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Check, X, AlertCircle, Home, RotateCcw, HelpCircle, BookOpen, AlertTriangle } from 'lucide-react';

interface ResultsPageProps {
  onBackToHome: () => void;
  onReviewAnswers: () => void;
}

export default function ResultsPage({ onBackToHome, onReviewAnswers }: ResultsPageProps) {
  const { results, questions } = useApp();
  const lastResult = results[0]; // get newest tryout result

  if (!lastResult) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <Home className="w-12 h-12 text-slate-400 mb-4" />
        <h3 className="font-display font-bold">Hasil Tidak Ditemukan</h3>
        <p className="text-sm text-slate-400">Kembali ke Dashboard untuk meluncurkan tryout.</p>
        <button onClick={onBackToHome} className="mt-4 px-6 py-2 rounded-xl bg-emerald-500 text-white font-semibold">Home Dashboard</button>
      </div>
    );
  }

  const { score, correctCount, wrongCount, percentage, isPassed, completedAt } = lastResult;
  const rank = Math.floor(Math.random() * 8) + 1; // Simulated ranking position out of classroom size

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      
      {/* Visual Header Pass/Fail Notification Hero Card */}
      <div className={`rounded-3xl p-6 sm:p-8 text-center text-white relative overflow-hidden shadow-xl ${
        isPassed
          ? "bg-gradient-to-tr from-emerald-600 to-teal-500"
          : "bg-gradient-to-tr from-rose-600 to-orange-500"
      }`}>
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full translate-x-12 -translate-y-12" />
        <div className="relative z-10 space-y-4">
          <div className="w-16 h-16 rounded-full bg-white/20 mx-auto flex items-center justify-center text-2xl">
            {isPassed ? "🎉" : "💪"}
          </div>
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 bg-white/20 rounded-full">
               Tryout Hasil Evaluasi Kompetensi
            </span>
            <h2 className="font-display text-3xl font-extrabold tracking-tight">
              {isPassed ? "Dinyatakan LULUS UKOM!" : "BELUM LULUS Passing Grade"}
            </h2>
          </div>
          <p className="text-slate-100 text-xs sm:text-sm max-w-md mx-auto leading-relaxed">
            {isPassed 
              ? "Luar biasa! Pertahankan konsistensi menjawab Anda untuk menghadapi Uji Kompetensi D3 Keperawatan sesungguhnya."
              : "Jangan menyerah! Analisis kembali pembahasan jawaban Anda untuk mematangkan diagnosa keperawatan yang masih keliru."}
          </p>
        </div>
      </div>

      {/* Score details grid layout */}
      <div className="grid sm:grid-cols-3 gap-6">
        
        {/* Score Card */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm text-center space-y-2">
          <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Skor Tryout Anda</p>
          <div className="text-5xl font-black font-display text-slate-900 dark:text-slate-100">{score}</div>
          <div className="text-xs text-slate-500">Nilai Kelolosan: 55.0%</div>
        </div>

        {/* Accuracy Bar Breakdown */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
          <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest text-center">Akurasi Jawaban</p>
          
          <div className="space-y-2.5">
            <div className="flex justify-between items-center text-xs">
              <span className="flex items-center gap-1.5 text-emerald-600 font-bold"><Check className="w-4 h-4" /> Benar</span>
              <span className="font-black">{correctCount} Soal</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="flex items-center gap-1.5 text-rose-500 font-bold"><X className="w-4 h-4" /> Salah</span>
              <span className="font-black">{wrongCount} Soal</span>
            </div>
            
            <div className="w-full h-3 bg-slate-100 dark:bg-slate-950 rounded-full overflow-hidden flex">
              <div 
                 style={{ width: `${percentage}%` }}
                 className="h-full bg-emerald-500 transition-all"
              />
              <div 
                 style={{ width: `${100 - percentage}%` }}
                 className="h-full bg-rose-500 transition-all"
              />
            </div>
          </div>
        </div>

        {/* Live Standings Rank Card */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm text-center space-y-2">
          <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Prediksi Peringkat</p>
          <div className="text-4xl font-extrabold font-display text-emerald-600 dark:text-teal-400">#{rank}</div>
          <div className="text-xs text-slate-500">Dari total peserta Tryout D3</div>
        </div>

      </div>

      {/* Actions and Next Steps */}
      <div className="flex flex-col sm:flex-row gap-4">
        <button
          onClick={onReviewAnswers}
          className="flex-1 py-4 bg-gradient-to-r from-emerald-600 to-teal-500 text-white font-bold text-sm rounded-2xl shadow-md uppercase hover:shadow-emerald-500/20 transition-all active:scale-95 flex items-center justify-center gap-2 pt-4.5"
        >
          <BookOpen className="w-5 h-5" /> Lihat Review & Pembahasan Lengkap
        </button>

        <button
          onClick={onBackToHome}
          className="py-4 px-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-950 rounded-2xl text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5"
        >
          <Home className="w-4 h-4" /> DST Dashboard
        </button>
      </div>

    </div>
  );
}
