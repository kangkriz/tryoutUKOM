import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { BookOpen, FolderMinus, PlusCircle, Trash, Server, FileText, CheckCircle, Clock } from 'lucide-react';
import { KisiKisi } from '../types';

export default function KisiKisiPage() {
  const { kisiKisi, addKisiKisi, deleteKisiKisi, currentUser } = useApp();
  const isAdmin = currentUser?.role === 'admin';
  
  const [showForm, setShowForm] = useState(false);
  const [category, setCategory] = useState('Keperawatan Medikal Bedah (KMB)');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;

    const newKisi: KisiKisi = {
       id: `kisi-${Date.now()}`,
       category,
       title,
       content,
       createdAt: new Date().toISOString()
    };

    await addKisiKisi(newKisi);
    setTitle('');
    setContent('');
    setShowForm(false);
    setSuccess('Kisi-kisi berhasil disimpan!');
    setTimeout(() => setSuccess(''), 3000);
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <h2 className="font-display text-xl font-extrabold flex items-center gap-2">
             <BookOpen className="w-5 h-5 text-emerald-500" /> Kisi-Kisi Kompetensi Perawat D3
          </h2>
          <p className="text-xs text-slate-400">Deskripsi silabus dan sebaran asuhan keperawatan standar nasional.</p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowForm(!showForm)}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-150 text-white dark:text-slate-950 font-bold text-xs rounded-xl transition-all flex items-center gap-2 pt-3"
          >
            <PlusCircle className="w-4 h-4" /> {showForm ? "Sembunyikan Form" : "Input Kisi-Kisi Baru"}
          </button>
        )}
      </div>

      {success && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/25 border border-emerald-100 dark:border-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs rounded-xl flex items-center gap-2">
           <CheckCircle className="w-4 h-4" /> {success}
        </div>
      )}

      {/* Admin Formulation Panel */}
      {isAdmin && showForm && (
        <form onSubmit={handleSubmit} className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
           <h4 className="font-display font-bold text-sm">Form Input Kisi-Kisi Materi</h4>
           
           <div className="grid sm:grid-cols-2 gap-4">
             <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400">Arsip Departemen / Materi</label>
                <select 
                   value={category}
                   onChange={e => setCategory(e.target.value)}
                   className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl"
                >
                  <option value="Keperawatan Medikal Bedah (KMB)">Keperawatan Medikal Bedah (KMB)</option>
                  <option value="Keperawatan Anak">Keperawatan Anak</option>
                  <option value="Keperawatan Maternitas">Keperawatan Maternitas</option>
                  <option value="Keperawatan Jiwa">Keperawatan Jiwa</option>
                  <option value="Keperawatan Keluarga">Keperawatan Keluarga</option>
                  <option value="Keperawatan Gerontik">Keperawatan Gerontik</option>
                  <option value="Keperawatan Gawat Darurat & Kritis">Keperawatan Gawat Darurat & Kritis</option>
                  <option value="Manajemen Keperawatan">Manajemen Keperawatan</option>
                </select>
             </div>
             <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400">Judul Kompetensi</label>
                <input 
                   type="text"
                   value={title}
                   onChange={e => setTitle(e.target.value)}
                   placeholder="Contoh: Asuhan Keperawatan Pasien COPD"
                   className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl"
                />
             </div>
           </div>

           <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-400">Deskripsi Kompetensi / Ringkasan Materi Penting</label>
              <textarea 
                 rows={4}
                 value={content}
                 onChange={e => setContent(e.target.value)}
                 placeholder="Uraikan kriteria penialaian, tindakan prioritas, atau diagnosa yang sering keluar..."
                 className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl"
              />
           </div>

           <button 
              type="submit"
              className="py-2.5 px-6 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold pt-3"
           >
              Simpan Kisi-Kisi Kompetensi
           </button>
        </form>
      )}

      {/* Grid displays */}
      <div className="grid md:grid-cols-2 gap-6">
         {kisiKisi.length === 0 ? (
           <div className="md:col-span-2 p-12 text-center text-slate-450 dark:text-slate-550 border rounded-3xl">
              <FolderMinus className="w-10 h-10 mx-auto stroke-1 text-slate-400 mb-2" />
              <p className="text-xs">Kisi-kisi belum ditayangkan oleh administrator.</p>
           </div>
         ) : (
           kisiKisi.map((item) => (
             <div key={item.id} className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-150 dark:border-slate-800 shadow-sm flex flex-col justify-between group hover:-translate-y-1 transition-all">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                     <span className="text-[10px] font-extrabold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-950 text-slate-500">{item.category}</span>
                     {isAdmin && (
                        <button 
                           onClick={() => deleteKisiKisi(item.id)}
                           className="p-1.5 hover:bg-rose-50 text-slate-450 hover:text-rose-600 dark:hover:bg-rose-950/20 rounded-md transition-colors"
                           title="Hapus Kisi-kisi"
                        >
                          <Trash className="w-3.5 h-3.5" />
                        </button>
                     )}
                  </div>
                  <h3 className="font-display font-extrabold text-base leading-snug group-hover:text-emerald-500 transition-colors">{item.title}</h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed whitespace-pre-wrap select-text">{item.content}</p>
                </div>

                <div className="flex items-center gap-1.5 text-[9px] text-slate-400 mt-4 border-t border-slate-100 dark:border-slate-800/80 pt-3">
                   <Clock className="w-3.5 h-3.5" /> Dibuat pada {new Date(item.createdAt).toLocaleDateString()}
                </div>
             </div>
           ))
         )}
      </div>

    </div>
  );
}
