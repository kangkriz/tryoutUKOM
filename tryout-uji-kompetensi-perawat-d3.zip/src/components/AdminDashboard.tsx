import { ShieldAlert, Users, BookOpen, BarChart3, Clock, Calendar, CheckCircle2, UserX, Info } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface AdminDashboardProps {
  onNavigatePage: (page: string) => void;
}

export default function AdminDashboard({ onNavigatePage }: AdminDashboardProps) {
  const { users, questions, results, announcements } = useApp();

  // Statistics
  const registeredParticipants = users.filter(u => u.role === 'user');
  const activeParticipantsCount = registeredParticipants.filter(u => u.status === 'active').length;
  const inActiveParticipantsCount = registeredParticipants.length - activeParticipantsCount;
  
  const totalQuestions = questions.length;
  const totalSubmissions = results.length;
  const averageAllScores = totalSubmissions > 0 
    ? parseFloat((results.reduce((sum, r) => sum + r.score, 0) / totalSubmissions).toFixed(1)) 
    : 0;

  // Let's create an elegant custom SVG-based score analytics charts to look extremely sleek without Recharts resolution errors
  const passedCount = results.filter(r => r.isPassed).length;
  const failedCount = totalSubmissions - passedCount;
  const passPercent = totalSubmissions > 0 ? parseFloat(((passedCount / totalSubmissions) * 100).toFixed(1)) : 0;
  
  return (
    <div className="space-y-8 pb-12">
      {/* Admin Title Welcome Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white p-6 sm:p-8 shadow-xl border border-slate-800">
        <div className="absolute top-0 right-0 w-64 h-64 bg-slate-800/20 rounded-full translate-x-12 -translate-y-12" />
        <div className="relative z-10 space-y-3 max-w-2xl">
          <div className="px-2.5 py-1 bg-emerald-500/15 rounded-full font-semibold text-[11px] text-emerald-400 inline-flex items-center gap-1.5 uppercase tracking-wider border border-emerald-500/20">
            ⚡ Administrator CBT Workspace
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight">
            Dashboard Pengawas Ujian
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed">
            Kelola data mahasiswa peserta, rancang bank soal CBT, review kelulusan Tryout Uji Kompetensi Perawat D3 secara komprehensif.
          </p>
        </div>
      </div>

      {/* Admin Quick Metrics Deck */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl text-indigo-600 dark:text-indigo-400">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <p className="text-10 text-slate-400 font-semibold tracking-wider uppercase">Jumlah Peserta</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-slate-100">{registeredParticipants.length} Orang</p>
            <p className="text-[10px] text-emerald-500 font-medium mt-0.5">{activeParticipantsCount} Aktif</p>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl text-emerald-600 dark:text-emerald-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <p className="text-10 text-slate-400 font-semibold tracking-wider uppercase">Bank Soal CBT</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-slate-100">{totalQuestions} Butir</p>
            <p className="text-[10px] text-slate-400 mt-0.5">Siap diacak (shuffle)</p>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-teal-50 dark:bg-teal-950/40 rounded-xl text-teal-600 dark:text-teal-400">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-10 text-slate-400 font-semibold tracking-wider uppercase">Rasio Kelulusan</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-slate-100">{passPercent}%</p>
            <p className="text-[10px] text-teal-500 font-medium mt-0.5">{passedCount} Lulus Ujian</p>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-cyan-50 dark:bg-cyan-950/40 rounded-xl text-cyan-600 dark:text-cyan-400">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-10 text-slate-400 font-semibold tracking-wider uppercase">Rerata Nilai</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-slate-100">{averageAllScores}%</p>
            <p className="text-[10px] text-slate-400 mt-0.5">Total {totalSubmissions} tryout</p>
          </div>
        </div>
      </div>

      {/* Admin Quick Action Banner to Input Announcement */}
      <div className="bg-gradient-to-r from-amber-500/10 via-rose-500/5 to-slate-50 dark:from-amber-500/10 dark:via-rose-500/5 dark:to-slate-900 px-6 py-5 rounded-3xl border border-amber-500/20 dark:border-amber-500/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="flex h-1.5 w-1.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-amber-500"></span>
            </span>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-600 dark:text-amber-400">Siaran Pengarah / Informasi Penting</span>
          </div>
          <h3 className="font-display font-extrabold text-base text-slate-800 dark:text-slate-100">Ingin Mengumumkan Jadwal Ujian atau Berita Baru?</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xl">
            Tulis pengumuman resmi, panduan kurikulum, atau tips ukom ke forum. Informasi ini akan langsung muncul secara real-time di halaman utama akun setiap peserta.
          </p>
        </div>
        <button 
          onClick={() => onNavigatePage('information')}
          className="px-4.5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-sm hover:shadow transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
        >
          <Info className="w-4 h-4 text-white" />
          <span>Buat & Input Informasi Baru</span>
        </button>
      </div>

      {/* Analytics Visualization and Activity Rows */}
      <div className="grid lg:grid-cols-3 gap-8">
        
        {/* Custom SVG Performance Analytics Chart */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6">
          <h3 className="font-display font-bold text-base">Statistik Kelulusan Tryout</h3>
          
          <div className="h-56 w-full flex flex-col justify-between items-center bg-slate-50 dark:bg-slate-950/40 rounded-2xl border border-slate-100 dark:border-slate-850 p-4">
            {totalSubmissions === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center gap-2 text-slate-400">
                <ShieldAlert className="w-10 h-10 stroke-1" />
                <p className="text-xs">Ujian belum ada yang diselesaikan.</p>
              </div>
            ) : (
              <div className="w-full h-full flex items-center justify-around relative">
                {/* Custom SVG Pie/Donut Chart */}
                <svg className="w-36 h-36" viewBox="0 0 36 36">
                  <path
                    className="text-slate-200 dark:text-slate-850 fill-none"
                    strokeWidth="3.5"
                    stroke="currentColor"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    className="text-emerald-500 fill-none transition-all duration-1000"
                    strokeWidth="3.5"
                    strokeDasharray={`${passPercent}, 100`}
                    strokeLinecap="round"
                    stroke="currentColor"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                
                <div className="absolute flex flex-col items-center text-center">
                  <span className="text-2xl font-black font-display text-emerald-500">{passPercent}%</span>
                  <span className="text-[9px] text-slate-400 tracking-wider uppercase">Lulus</span>
                </div>

                <div className="text-xs space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0" />
                    <span>Lulus: <b>{passedCount}</b></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-slate-250 dark:bg-slate-800 shrink-0" />
                    <span>Lolos: <b>{failedCount}</b></span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2">
            <button
               onClick={() => onNavigatePage('users')}
               className="py-2.5 rounded-xl text-center text-[10px] font-extrabold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/35 text-indigo-600 dark:text-indigo-400 transition-all"
            >
              Kelola Pengguna
            </button>
            <button
               onClick={() => onNavigatePage('questions')}
               className="py-2.5 rounded-xl text-center text-[10px] font-extrabold bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/35 text-emerald-600 dark:text-emerald-400 transition-all"
            >
              Urus Bank Soal
            </button>
            <button
               onClick={() => onNavigatePage('information')}
               className="py-2.5 rounded-xl text-center text-[10px] font-extrabold bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/35 text-amber-600 dark:text-amber-400 transition-all font-sans"
            >
              Input Informasi
            </button>
          </div>
        </div>

        {/* Recent Tryout Log Activities list */}
        <div className="lg:col-span-2 p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
             <h3 className="font-display font-bold text-base">Aktivitas Ujian Terbaru</h3>
             <button
                onClick={() => onNavigatePage('history')}
                className="text-emerald-500 hover:text-emerald-600 text-xs font-semibold"
             >
               Seluruh Nilai
             </button>
          </div>

          <div className="space-y-4 divide-y divide-slate-100 dark:divide-slate-800">
            {results.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-12">Belum ada peserta yang mengumpulkan ukom.</p>
            ) : (
              results.slice(0, 5).map((res) => (
                <div key={res.id} className="pt-4 first:pt-0 flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <p className="font-bold text-sm text-slate-800 dark:text-slate-100">{res.userName}</p>
                    <div className="flex items-center gap-3 text-xs text-slate-400">
                       <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {new Date(res.completedAt).toLocaleDateString()}</span>
                       <span className="px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-950 font-semibold">{res.correctCount} Benar</span>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-sm font-black text-slate-900 dark:text-slate-100 font-display">{res.score}%</div>
                    <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold mt-1 ${
                      res.isPassed 
                        ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400"
                        : "bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400"
                    }`}>
                      {res.isPassed ? "Lulus UKOM" : "Belum Lulus"}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
