import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Award, ClipboardX, Calendar, Search, Trash, Eye, ArrowUpRight, TrendingUp } from 'lucide-react';

interface HistoryPageProps {
  onReviewSelectedResult: (resultId: string) => void;
}

export default function HistoryPage({ onReviewSelectedResult }: HistoryPageProps) {
  const { results, currentUser, deleteResult } = useApp();
  const isAdmin = currentUser?.role === 'admin';
  const [searchQuery, setSearchQuery] = useState('');

  // Filter based on currentUser role
  const filteredResults = results
    .filter((r) => {
      // Participant sees only their own; Admin sees everything
      if (!isAdmin) return r.userId === currentUser?.id;
      return true;
    })
    .filter((r) => {
      // Apply search bar matches
      if (!searchQuery) return true;
      return r.userName.toLowerCase().includes(searchQuery.toLowerCase());
    });

  // Calculate stats for SVG evolution charts of participant scores
  const chronologicalHistory = [...filteredResults].reverse(); // oldest to newest
  const totalHistoricPoints = chronologicalHistory.length;
  
  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <h2 className="font-display text-xl font-extrabold flex items-center gap-2">
             <TrendingUp className="w-5 h-5 text-emerald-500" /> Riwayat Nilai & Hasil Ujian
          </h2>
          <p className="text-xs text-slate-400">Rekapan hasil ujian CBT yang telah dikumpulkan serta statistik perkembangan.</p>
        </div>

        {/* Search bar for admin log tracking */}
        {isAdmin && (
          <div className="relative w-full sm:w-64">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
               <Search className="w-4 h-4" />
            </span>
            <input 
               type="text"
               value={searchQuery}
               onChange={e => setSearchQuery(e.target.value)}
               placeholder="Cari nama peserta..."
               className="w-full pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border text-xs rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>
        )}
      </div>

      {/* Visual Chart: Score development history for participants */}
      {!isAdmin && totalHistoricPoints > 0 && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-150 dark:border-slate-800 shadow-sm space-y-4">
           <h3 className="font-display font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
              📊 Grafik Tren Perkembangan Nilai Tryout
           </h3>
           
           <div className="h-44 w-full flex items-end justify-between gap-2 bg-slate-50 dark:bg-slate-950/45 rounded-2xl border p-4 pt-8 border-slate-150 dark:border-slate-850 relative">
              {/* Score lines indicators */}
              <div className="absolute left-4 top-2 text-[10px] text-slate-400">Skor: 100%</div>
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 border-t border-dashed w-[94%], h-0 border-slate-200">Skor: 50%</div>

              {chronologicalHistory.map((h, i) => (
                <div key={h.id} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group relative">
                   {/* Popover score values */}
                   <div className="absolute -top-7 bg-slate-900 text-white text-[10px] font-bold px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 shadow">
                      {h.score}% ({i + 1})
                   </div>

                   {/* Custom SVG/Div Bar representation */}
                   <div 
                      style={{ height: `${h.score}%` }}
                      className={`w-4 sm:w-6 rounded-t-lg transition-all duration-500 ${
                        h.isPassed 
                          ? "bg-gradient-to-t from-emerald-600 to-emerald-400 group-hover:from-emerald-500Group" 
                          : "bg-gradient-to-t from-rose-500 to-rose-400 text-transparent"
                      }`}
                   />
                   
                   <span className="text-[9px] text-slate-400 font-bold">T-{i + 1}</span>
                </div>
              ))}
           </div>
        </div>
      )}

      {/* Main Table logs display list */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-150 dark:border-slate-800 shadow-sm overflow-hidden">
         {filteredResults.length === 0 ? (
           <div className="p-16 text-center text-slate-450">
              <ClipboardX className="w-12 h-12 mx-auto stroke-1 mb-2 text-slate-350 dark:text-slate-750" />
              <p className="text-sm font-medium">Belum ada histori pengerjaan Tryout.</p>
           </div>
         ) : (
           <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                 <thead>
                    <tr className="bg-slate-50 dark:bg-slate-950/80 text-slate-400 uppercase font-extrabold tracking-wider border-b border-slate-150 dark:border-slate-850">
                       <th className="py-4 px-6">Peserta / Tanggal</th>
                       <th className="py-4 px-6 text-center">Soal Benar</th>
                       <th className="py-4 px-6 text-center">Soal Salah</th>
                       <th className="py-4 px-6 text-center">Akurasi</th>
                       <th className="py-4 px-6 text-center">Skor Akhir</th>
                       <th className="py-4 px-6 text-center">Kelolosan</th>
                       <th className="py-4 px-6 text-center">Aksi</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredResults.map((res) => (
                      <tr key={res.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/10 transition-colors">
                         <td className="py-4 px-6 space-y-1">
                            <p className="font-extrabold text-sm text-slate-800 dark:text-slate-100">{res.userName}</p>
                            <p className="text-[10px] text-slate-400 flex items-center gap-1">
                               <Calendar className="w-3.5 h-3.5" />
                               {new Date(res.completedAt).toLocaleString('id-ID')}
                            </p>
                         </td>
                         <td className="py-4 px-6 text-center font-bold text-emerald-600">{res.correctCount} Butir</td>
                         <td className="py-4 px-6 text-center font-bold text-rose-550">{res.wrongCount} Butir</td>
                         <td className="py-4 px-6 text-center font-mono font-medium">{res.percentage}%</td>
                         <td className="py-4 px-6 text-center font-black text-sm font-display text-slate-900 dark:text-slate-100">{res.score}%</td>
                         <td className="py-4 px-6 text-center">
                            <span className={`inline-flex px-2.5 py-1 rounded-full text-[10px] font-bold ${
                               res.isPassed 
                                 ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400"
                                 : "bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400"
                            }`}>
                               {res.isPassed ? "LULUS UKOM" : "BELUM LULUS"}
                            </span>
                         </td>
                         <td className="py-4 px-6 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                               <button 
                                  onClick={() => onReviewSelectedResult(res.id)}
                                  className="p-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-950 hover:text-emerald-500 rounded-lg text-slate-500 transition-colors text-[10px] font-bold flex items-center gap-1"
                               >
                                 <Eye className="w-3.5 h-3.5" /> Review
                               </button>

                               {isAdmin && (
                                  <button 
                                     onClick={() => deleteResult(res.id)}
                                     className="p-1.5 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/30 rounded-lg text-slate-450 transition-colors"
                                     title="Hapus Nilai"
                                  >
                                    <Trash className="w-3.5 h-3.5" />
                                  </button>
                               )}
                            </div>
                         </td>
                      </tr>
                    ))}
                 </tbody>
              </table>
           </div>
         )}
      </div>

    </div>
  );
}
