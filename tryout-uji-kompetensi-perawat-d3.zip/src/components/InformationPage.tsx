import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Info, PlusCircle, Trash, CloudLightning, Image, CheckCircle } from 'lucide-react';
import { Announcement } from '../types';

export default function InformationPage() {
  const { announcements, addAnnouncement, deleteAnnouncement, currentUser } = useApp();
  const isAdmin = currentUser?.role === 'admin';

  const [showForm, setShowForm] = useState(isAdmin);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [bannerUrl, setBannerUrl] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;

    // Use a default stock photo banner if none is defined
    const url = bannerUrl.trim() || "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=1200";

    const newAnn: Announcement = {
       id: `ann-${Date.now()}`,
       title,
       content,
       bannerUrl: url,
       createdAt: new Date().toISOString()
    };

    await addAnnouncement(newAnn);
    setTitle('');
    setContent('');
    setBannerUrl('');
    setShowForm(false);
    setSuccess('Pengumuman berhasil dipublikasikan!');
    setTimeout(() => setSuccess(''), 3000);
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <h2 className="font-display text-xl font-extrabold flex items-center gap-2">
             <Info className="w-5 h-5 text-emerald-500" /> Informasi & Pengumuman Terbaru
          </h2>
          <p className="text-xs text-slate-400">Pemberitahuan resmi kualifikasi, jadwal Tryout, serta tips ukom.</p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowForm(!showForm)}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-150 text-white dark:text-slate-950 font-bold text-xs rounded-xl transition-all flex items-center gap-2 pt-3"
          >
            <PlusCircle className="w-4 h-4" /> {showForm ? "Sembunyikan Form" : "Buat Pengumuman Baru"}
          </button>
        )}
      </div>

      {success && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/25 border border-emerald-100 dark:border-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs rounded-xl flex items-center gap-2">
           <CheckCircle className="w-4 h-4" /> {success}
        </div>
      )}

      {/* Admin Formulation Panel */}
      {isAdmin && showForm && (
        <form onSubmit={handleSubmit} className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
           <h4 className="font-display font-bold text-sm">Form Pembuatan Informasi / Banner Info</h4>
           
           <div className="grid sm:grid-cols-2 gap-4">
             <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400">Judul Informasi</label>
                <input 
                   type="text"
                   required
                   value={title}
                   onChange={e => setTitle(e.target.value)}
                   placeholder="Contoh: Tryout Gelombang Ke-3 Segera Dimulai"
                   className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl"
                />
             </div>
             <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400">Gambar Banner URL (Opsional)</label>
                <input 
                   type="text"
                   value={bannerUrl}
                   onChange={e => setBannerUrl(e.target.value)}
                   placeholder="https://..."
                   className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl"
                />
             </div>
           </div>

           <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-400">Isi Pengumuman</label>
              <textarea 
                 rows={4}
                 required
                 value={content}
                 onChange={e => setContent(e.target.value)}
                 placeholder="Tuliskan berita lengkap pengumuman di sini..."
                 className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-950 border text-xs rounded-xl"
              />
           </div>

           <button 
              type="submit"
              className="py-2.5 px-6 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold pt-3"
           >
              Siarkan Pengumuman Informasi
           </button>
        </form>
      )}

      {/* Announcements Board Container */}
      <div className="space-y-8">
         {announcements.length === 0 ? (
           <div className="p-12 text-center text-slate-400 border rounded-3xl">
              <CloudLightning className="w-10 h-10 mx-auto stroke-1 mb-2" />
              <p className="text-xs">Berita papan pengumuman kosong.</p>
           </div>
         ) : (
           announcements.map((ann) => (
             <div key={ann.id} className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-150 dark:border-slate-800 overflow-hidden shadow-sm grid md:grid-cols-3 items-stretch hover:shadow-md transition-shadow">
                
                {ann.bannerUrl && (
                  <div className="relative h-48 md:h-full">
                    <img 
                       src={ann.bannerUrl}
                       alt="Banner"
                       referrerPolicy="no-referrer"
                       className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                <div className={`p-6 sm:p-8 flex flex-col justify-between ${ann.bannerUrl ? "md:col-span-2" : "md:col-span-3"}`}>
                   <div className="space-y-4">
                     <div className="flex justify-between items-start">
                        <span className="text-[10px] font-extrabold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/25 text-emerald-600 dark:text-emerald-400">Broadcast Pengumuman</span>
                        {isAdmin && (
                           <button 
                              onClick={() => deleteAnnouncement(ann.id)}
                              className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 dark:hover:bg-rose-950/25 rounded-lg transition-colors"
                              title="Hapus Informasi"
                           >
                             <Trash className="w-4 h-4" />
                           </button>
                        )}
                     </div>
                     <h3 className="font-display font-extrabold text-xl leading-snug">{ann.title}</h3>
                     <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed whitespace-pre-wrap select-text">{ann.content}</p>
                   </div>

                   <p className="text-[10px] text-slate-400 mt-6 border-t border-slate-100 dark:border-slate-800/80 pt-3 flex items-center gap-1.5">
                     Disiarkan pada {new Date(ann.createdAt).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                   </p>
                </div>
             </div>
           ))
         )}
      </div>

    </div>
  );
}
