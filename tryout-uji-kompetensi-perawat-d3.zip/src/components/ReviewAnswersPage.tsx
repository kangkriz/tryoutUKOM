import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Check, X, ArrowLeft, Award, HelpCircle, Eye, AlertTriangle, BookOpen } from 'lucide-react';
import { Question } from '../types';

interface ReviewAnswersPageProps {
  onBackToResults: () => void;
  selectedResultId?: string | null;
}

type FilterMode = 'all' | 'correct' | 'wrong' | 'flagged';

export default function ReviewAnswersPage({ onBackToResults, selectedResultId }: ReviewAnswersPageProps) {
  const { results, questions, cbtQuestions } = useApp();
  const [filter, setFilter] = useState<FilterMode>('all');
  const [selectedIndex, setSelectedIndex] = useState(0);

  // Get newest Tryout submission or the selected historic database result
  const currentSubmission = selectedResultId 
    ? results.find(r => r.id === selectedResultId) 
    : results[0];

  if (!currentSubmission) {
    return (
      <div className="max-w-4xl mx-auto p-12 text-center text-slate-400">
         <BookOpen className="w-12 h-12 mx-auto mb-4 stroke-1" />
         <h3 className="font-display font-bold">Data Nilai Tidak Ditemukan</h3>
         <button onClick={onBackToResults} className="mt-4 px-6 py-2 rounded-xl bg-slate-900 border">Kembali</button>
      </div>
    );
  }

  // Find exact question pool of the Tryout
  // If the test state was cleared, we can safely search across generic global questions database
  const activeQuestionsPool = cbtQuestions.length > 0 ? cbtQuestions : questions;

  const { answers, flagged } = currentSubmission;

  // Filter based on selected pills
  const filteredQuestions = activeQuestionsPool.filter((q) => {
    const studentAns = answers[q.id];
    const isCorrect = studentAns === q.correctAnswer;
    const isDoubt = flagged.includes(q.id);

    if (filter === 'correct') return isCorrect;
    if (filter === 'wrong') return !isCorrect;
    if (filter === 'flagged') return isDoubt;
    return true;
  });

  const activeQuestion = filteredQuestions[selectedIndex] || filteredQuestions[0];

  const handleSelectIndex = (idx: number) => {
    setSelectedIndex(idx);
  };

  const handlePrev = () => {
    if (selectedIndex > 0) setSelectedIndex(selectedIndex - 1);
  };

  const handleNext = () => {
    if (selectedIndex < filteredQuestions.length - 1) setSelectedIndex(selectedIndex + 1);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      
      {/* Header Back navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
        <button
          onClick={onBackToResults}
          className="inline-flex items-center gap-2 text-slate-500 hover:text-slate-800 dark:hover:text-white font-medium text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Kembali ke Hasil Nilai
        </button>

        <h2 className="font-display text-xl font-extrabold">Review & Pembahasan Jawaban</h2>
      </div>

      {/* Filter Mode Pills Switcher */}
      <div className="flex flex-wrap items-center gap-2">
        {(['all', 'correct', 'wrong', 'flagged'] as const).map((mode) => {
          let label = "Semua Soal";
          if (mode === 'correct') label = "Jawaban Benar";
          if (mode === 'wrong') label = "Jawaban Salah";
          if (mode === 'flagged') label = "Ragu-Ragu";

          const isActive = filter === mode;
          let activeStyles = "bg-slate-900 text-white dark:bg-white dark:text-slate-950";
          if (isActive && mode === 'correct') activeStyles = "bg-emerald-500 text-white";
          if (isActive && mode === 'wrong') activeStyles = "bg-rose-500 text-white";
          if (isActive && mode === 'flagged') activeStyles = "bg-amber-500 text-white";

          return (
            <button
              key={mode}
              onClick={() => { setFilter(mode); setSelectedIndex(0); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                isActive 
                  ? activeStyles
                  : "bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-950 border border-slate-150 dark:border-slate-800 text-slate-500 dark:text-slate-400"
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Double Column: Sidebar + Detail area */}
      {filteredQuestions.length === 0 ? (
        <div className="p-16 bg-white dark:bg-slate-900 rounded-3xl border text-center text-slate-400 border-slate-150 dark:border-slate-800">
           <Eye className="w-12 h-12 mx-auto stroke-1 text-slate-350 dark:text-slate-700 mb-2" />
           <p className="text-sm font-medium">Tidak ada butir soal yang sesuai dengan pencarian tab filter ini.</p>
        </div>
      ) : (
        <div className="grid lg:grid-cols-4 gap-6 items-start">
          
          {/* Layout Numbers Grid map */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 max-h-[450px] overflow-y-auto">
            <h4 className="font-display font-medium text-xs tracking-wider uppercase text-slate-400">Map Navigasi</h4>
            
            <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-4 gap-2">
              {filteredQuestions.map((q, idx) => {
                const studentAns = answers[q.id];
                const isCorrect = studentAns === q.correctAnswer;
                const isSelected = idx === selectedIndex;

                let badgeStyle = "bg-rose-50 dark:bg-rose-950/20 text-rose-500 dark:text-rose-400";
                if (isCorrect) {
                  badgeStyle = "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-500 dark:text-emerald-400";
                }

                return (
                  <button
                    key={q.id}
                    onClick={() => handleSelectIndex(idx)}
                    className={`w-full aspect-square text-xs font-black rounded-lg border flex items-center justify-center transition-all ${badgeStyle} ${
                      isSelected ? "ring-2 ring-indigo-500 scale-105 border-indigo-500" : ""
                    }`}
                  >
                    {(idx + 1).toString().padStart(2, '0')}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Detailed Question Review Panel */}
          <div className="lg:col-span-3 space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
              
              {/* Question Header */}
              <div className="p-5 bg-slate-50 dark:bg-slate-950 border-b border-slate-150 dark:border-slate-850 flex items-center justify-between">
                <span className="text-xs font-semibold text-mono text-slate-400">Soal Nomor {selectedIndex + 1}</span>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-150 dark:bg-slate-900 border text-slate-500">{activeQuestion.category}</span>
              </div>

              {/* Vignette body */}
              <div className="p-6 sm:p-8 space-y-6">
                <p className="text-slate-800 dark:text-slate-200 text-base leading-relaxed whitespace-pre-wrap font-normal select-text">
                  {activeQuestion.question}
                </p>

                {/* Imagery attachment */}
                {activeQuestion.imageUrl && (
                  <div className="my-4 rounded-xl overflow-hidden max-w-sm border">
                    <img src={activeQuestion.imageUrl} alt="attachment" referrerPolicy="no-referrer" />
                  </div>
                )}

                {/* Option list choices showing correctness */}
                <div className="space-y-3.5 border-t border-slate-100 dark:border-slate-800 pt-6">
                  {[
                    { key: 'A', text: activeQuestion.optionA },
                    { key: 'B', text: activeQuestion.optionB },
                    { key: 'C', text: activeQuestion.optionC },
                    { key: 'D', text: activeQuestion.optionD },
                    { key: 'E', text: activeQuestion.optionE }
                  ].map(({ key, text }) => {
                    const studentAns = answers[activeQuestion.id];
                    const correctChoice = activeQuestion.correctAnswer;
                    
                    const isStudentChosen = studentAns === key;
                    const isCorrectKey = correctChoice === key;

                    let optionBorder = "border-slate-150 dark:border-slate-850 bg-slate-50/20";
                    let iconBadge = null;

                    if (isCorrectKey) {
                      // Correct option is always colored Green so the student sees the model standard choice!
                      optionBorder = "border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300";
                      iconBadge = <Check className="w-4 h-4 text-emerald-500 stroke-[3]" />;
                    } else if (isStudentChosen && !isCorrectKey) {
                      // Student answer was wrong! Colored Rose.
                      optionBorder = "border-rose-400 bg-rose-50/50 dark:bg-rose-950/20 text-rose-850 dark:text-rose-400";
                      iconBadge = <X className="w-4 h-4 text-rose-500 stroke-[3]" />;
                    }

                    return (
                      <div
                        key={key}
                        className={`p-4 rounded-2xl border flex items-start gap-4 transition-all text-sm leading-relaxed ${optionBorder}`}
                      >
                        <span className={`w-6 h-6 rounded-full font-bold flex items-center justify-center shrink-0 uppercase text-xs ${
                          isCorrectKey ? "bg-emerald-500 text-white" : isStudentChosen ? "bg-rose-500 text-white" : "bg-slate-100 dark:bg-slate-950 text-slate-400"
                        }`}>
                          {key}
                        </span>
                        
                        <div className="flex-1">
                           <p className="leading-relaxed">{text}</p>
                           {isStudentChosen && isCorrectKey && (
                             <span className="inline-flex text-[10px] font-black uppercase text-emerald-600 dark:text-emerald-400 mt-1.5">✓ Jawaban Anda Benar</span>
                           )}
                           {isStudentChosen && !isCorrectKey && (
                             <span className="inline-flex text-[10px] font-black uppercase text-rose-600 dark:text-rose-400 mt-1.5 font-bold">✗ Jawaban Anda Salah</span>
                           )}
                        </div>

                        {iconBadge}
                      </div>
                    );
                  })}
                </div>

                {/* Detailed Pembahasan / Rasionalisasi Keperawatan */}
                <div className="p-5 sm:p-6 rounded-2xl bg-indigo-50/55 dark:bg-slate-950 border border-indigo-150/40 dark:border-slate-850/80 space-y-3">
                  <h5 className="font-display font-black text-sm text-indigo-900 dark:text-indigo-400 flex items-center gap-2">
                     <BookOpen className="w-4 h-4 text-indigo-500" /> Rasionalisasi & Pembahasan Ilmiah
                  </h5>
                  <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed font-normal whitespace-pre-wrap select-text">
                    {activeQuestion.explanation || "Pembahasan komprehensif belum didefinisikan untuk soal ini."}
                  </p>
                </div>

              </div>

              {/* Prev/Next buttons under details */}
              <div className="px-6 py-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-150 dark:border-slate-850 flex items-center justify-between">
                <button
                  onClick={handlePrev}
                  disabled={selectedIndex === 0}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 disabled:opacity-30 text-xs font-semibold hover:bg-slate-50 transition-colors"
                >
                  Sebelumnya
                </button>

                <button
                  onClick={handleNext}
                  disabled={selectedIndex === filteredQuestions.length - 1}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 disabled:opacity-30 text-xs font-semibold hover:bg-slate-50 transition-colors"
                >
                  Berikutnya
                </button>
              </div>

            </div>
          </div>

        </div>
      )}

    </div>
  );
}
