import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserPlus, ToggleLeft, ToggleRight, Trash2, Shield, User, Key, CheckCircle, Search, Edit3 } from 'lucide-react';
import { UserRole, AccountStatus, User as AppUser } from '../types';

export default function ManageUsersPage() {
  const { users, addUser, updateUserStatus, deleteUser } = useApp();
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.USER);
  const [password, setPassword] = useState('');
  const [success, setSuccess] = useState('');

  // Password edit overlay states
  const [editingUserPass, setEditingUserPass] = useState<string | null>(null);
  const [newPasswordVal, setNewPasswordVal] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;

    const matched = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    if (matched) {
      alert('Email sudah digunakan oleh peserta lain.');
      return;
    }

    // Default password if not specified
    const finalPassword = password.trim() || (role === UserRole.ADMIN ? 'admin123' : 'peserta123');

    const newUser: AppUser = {
      id: `u-${Date.now()}`,
      name: name.trim().toUpperCase(),
      email: email.trim().toLowerCase(),
      role,
      status: AccountStatus.ACTIVE,
      password: finalPassword,
      createdAt: new Date().toISOString()
    };

    await addUser(newUser);
    setName('');
    setEmail('');
    setPassword('');
    setShowForm(false);
    setSuccess(`Peserta baru ${newUser.name} berhasil didaftarkan dengan kata sandi "${finalPassword}"!`);
    setTimeout(() => setSuccess(''), 4500);
  };

  const handleSavePassword = async (user: AppUser) => {
    if (!newPasswordVal.trim()) {
      alert('Sandi tidak boleh kosong!');
      return;
    }

    const updatedUser = {
      ...user,
      password: newPasswordVal.trim()
    };

    await addUser(updatedUser); // This updates user data inside context and Firestore repo
    setEditingUserPass(null);
    setNewPasswordVal('');
    setSuccess(`Sandi untuk peserta ${user.name} berhasil diubah menjadi "${updatedUser.password}"!`);
    setTimeout(() => setSuccess(''), 4000);
  };

  const filteredUsers = users.filter((u) => {
    return u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <h2 className="font-display text-xl font-extrabold flex items-center gap-2">
             <UserPlus className="w-5 h-5 text-emerald-500" /> Manajemen Pengguna & Peserta
          </h2>
          <p className="text-xs text-slate-400">Daftarkan peserta ujian CBT Baru, buat kata sandi khusus, serta kelola status keaktifan akun.</p>
        </div>

        <button
          onClick={() => setShowForm(!showForm)}
          className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 font-bold text-xs rounded-xl transition-all flex items-center gap-2 pt-3 cursor-pointer"
        >
          <UserPlus className="w-4 h-4" /> {showForm ? "Sembunyikan Form" : "Daftarkan Peserta Baru"}
        </button>
      </div>

      {success && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/25 border border-emerald-100 dark:border-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs rounded-xl flex items-center gap-2 shadow-sm animate-in fade-in duration-300">
           <CheckCircle className="w-4 h-5 text-emerald-500 shrink-0" /> 
           <span className="font-medium">{success}</span>
        </div>
      )}

      {/* Manual Registration Form Container */}
      {showForm && (
        <form onSubmit={handleSubmit} className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-150 dark:border-slate-800/80 shadow-md space-y-4 animate-in slide-in-from-top-4 duration-300">
           <h4 className="font-display font-black text-sm text-slate-800 dark:text-slate-200">Registrasi Peserta Baru</h4>
           
           <div className="grid sm:grid-cols-4 gap-4">
             <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400 dark:text-slate-500">Nama Lengkap Mahasiswa</label>
                <input 
                   type="text"
                   required
                   value={name}
                   onChange={e => setName(e.target.value)}
                   placeholder="Contoh: SITI AMINAH"
                   className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-500 dark:text-white"
                />
             </div>
             
             <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400 dark:text-slate-500">Email Portal CBT</label>
                <input 
                   type="email"
                   required
                   value={email}
                   onChange={e => setEmail(e.target.value)}
                   placeholder="siti@ukom.id"
                   className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-500 dark:text-white"
                />
             </div>

             <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400 dark:text-slate-500">Kunci Masuk / Sandi Akun</label>
                <input 
                   type="text"
                   value={password}
                   onChange={e => setPassword(e.target.value)}
                   placeholder="Default: peserta123"
                   className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-500 dark:text-white"
                />
             </div>

             <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400 dark:text-slate-500">Hak Akses Portal</label>
                <select
                   value={role}
                   onChange={e => setRole(e.target.value as UserRole)}
                   className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-500 font-semibold text-slate-700 dark:text-slate-300"
                >
                   <option value={UserRole.USER}>Peserta CBT (Mahasiswa)</option>
                   <option value={UserRole.ADMIN}>Administrator (Pengawas)</option>
                </select>
             </div>
           </div>

           <button 
              type="submit"
              className="py-2.5 px-6 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold pt-3 shadow active:scale-95 transition-all cursor-pointer"
           >
              Kukuhkan Pendaftaran Peserta
           </button>
        </form>
      )}

      {/* Users listing grid */}
      <div className="space-y-4">
         <div className="relative w-full sm:w-64">
           <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
              <Search className="w-4 h-4" />
           </span>
           <input 
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Cari email atau nama peserta..."
              className="w-full pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 text-xs rounded-xl focus:outline-none"
           />
         </div>

         <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
               <table className="w-full text-left font-normal border-collapse text-xs">
                  <thead>
                     <tr className="bg-slate-50 dark:bg-slate-950/80 text-slate-400 uppercase font-extrabold tracking-wider border-b border-slate-150 dark:border-slate-850">
                        <th className="py-4 px-6">Informasi Peserta & Kredensial</th>
                        <th className="py-4 px-6 text-center">Tipe Peran</th>
                        <th className="py-4 px-6 text-center">Status Keaktifan</th>
                        <th className="py-4 px-6 text-center">Waktu Registrasi</th>
                        <th className="py-4 px-6 text-center">Aksi / Reset Sandi</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                     {filteredUsers.map((u) => {
                       const isAct = u.status === 'active';
                       return (
                         <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/10 transition-colors">
                            <td className="py-4 px-6 space-y-1">
                               <p className="font-extrabold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                                  <User className="w-4 h-4 text-slate-400 shrink-0" />
                                  {u.name}
                               </p>
                               <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-slate-400">
                                  <span className="font-mono font-medium">{u.email}</span>
                                  <span className="text-slate-300 dark:text-slate-700">|</span>
                                  <span className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded text-slate-500 dark:text-slate-400 font-mono text-[10px]">
                                     <Key className="w-3 h-3 text-amber-500 shrink-0" /> Sandi: <strong className="text-slate-700 dark:text-slate-200 font-bold">{u.password || 'peserta123'}</strong>
                                  </span>
                               </div>
                            </td>
                            <td className="py-4 px-6 text-center font-semibold">
                               <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] ${
                                 u.role === 'admin' 
                                   ? "bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400 border border-indigo-200"
                                   : "bg-teal-50 dark:bg-teal-950/20 text-teal-600 dark:text-teal-400 border border-teal-200/30"
                               }`}>
                                 {u.role === 'admin' ? "Admin / Pengawas" : "Peserta CBT"}
                               </span>
                            </td>
                            <td className="py-4 px-6 text-center">
                               <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                                 isAct 
                                   ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600"
                                   : "bg-rose-50 dark:bg-rose-950/40 text-rose-600"
                               }`}>
                                 {isAct ? "Aktif" : "Dinonaktifkan"}
                               </span>
                            </td>
                            <td className="py-4 px-6 text-center text-slate-400">
                               {new Date(u.createdAt).toLocaleDateString()}
                            </td>
                            <td className="py-4 px-6 text-center">
                               {editingUserPass === u.id ? (
                                 <div className="inline-flex items-center gap-1.5 bg-amber-500/10 dark:bg-amber-500/5 p-1.5 rounded-xl border border-amber-500/20 shadow-sm animate-in zoom-in-95 duration-150">
                                   <input 
                                     type="text" 
                                     value={newPasswordVal}
                                     onChange={e => setNewPasswordVal(e.target.value)}
                                     placeholder="Kunci baru..."
                                     className="px-2 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[10px] rounded-lg w-28 focus:outline-none focus:ring-1 focus:ring-amber-500 text-slate-800 dark:text-white font-mono font-bold"
                                   />
                                   <button 
                                     onClick={() => handleSavePassword(u)}
                                     className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white text-[10px] font-black rounded-lg cursor-pointer transition-colors"
                                   >
                                     Simpan
                                   </button>
                                   <button 
                                     onClick={() => { setEditingUserPass(null); setNewPasswordVal(''); }}
                                     className="px-2 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-300 text-[10px] font-bold rounded-lg cursor-pointer transition-colors"
                                   >
                                     Batal
                                   </button>
                                 </div>
                               ) : (
                                 <div className="flex items-center justify-center gap-1.5">
                                    <button
                                       onClick={() => { setEditingUserPass(u.id); setNewPasswordVal(u.password || 'peserta123'); }}
                                       className="p-1.5 hover:bg-amber-50 dark:hover:bg-amber-950/20 text-slate-400 hover:text-amber-500 rounded-lg transition-colors cursor-pointer"
                                       title="Ubah / Reset Kata Sandi"
                                    >
                                       <Key className="w-4 h-4 shrink-0" />
                                    </button>

                                    <button
                                       onClick={() => updateUserStatus(u.id, isAct ? AccountStatus.INACTIVE : AccountStatus.ACTIVE)}
                                       className={`p-1 hover:bg-slate-50 dark:hover:bg-slate-950/25 rounded-lg text-slate-500 transition-colors cursor-pointer ${
                                         isAct ? "text-emerald-500 hover:text-emerald-600" : "text-rose-500 hover:text-rose-600"
                                       }`}
                                       title={isAct ? "Deaktifkan Peserta" : "Aktifkan Peserta"}
                                    >
                                       {isAct ? <ToggleRight className="w-5 h-5 shrink-0" /> : <ToggleLeft className="w-5 h-5 shrink-0" />}
                                    </button>

                                    <button 
                                       onClick={() => {
                                         if (confirm(`Yakin ingin menghapus secara permanen pendaftaran ${u.name}?`)) {
                                           deleteUser(u.id);
                                         }
                                       }}
                                       className="p-1.5 hover:bg-rose-50 dark:hover:bg-rose-950/20 hover:text-rose-600 rounded-lg text-slate-400 transition-colors cursor-pointer"
                                       title="Hapus Peserta"
                                    >
                                       <Trash2 className="w-4 h-4 shrink-0" />
                                    </button>
                                 </div>
                               )}
                            </td>
                         </tr>
                       );
                     })}
                  </tbody>
               </table>
            </div>
         </div>
      </div>

    </div>
  );
}
