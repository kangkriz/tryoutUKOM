import { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { ShieldAlert, BookOpen, Clock, AlertTriangle, ArrowLeft, ArrowRight, Save, Maximize, CheckCircle2, RefreshCw } from 'lucide-react';

interface CBTExamPageProps {
  onScoreSubmitted: () => void;
}

export default function CBTExamPage({ onScoreSubmitted }: CBTExamPageProps) {
  const { cbtQuestions, cbtState, setAnswerForCBT, toggleFlagCBT, setCurrentIndexCBT, tickTimerCBT, submitCBT, cancelCBT } = useApp();
  const [submitting, setSubmitting] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // Guard against missing state
  if (!cbtState || cbtQuestions.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <ShieldAlert className="w-12 h-12 text-slate-400 mb-4" />
        <h3 className="font-display font-bold">Ujian Tidak Aktif</h3>
        <p className="text-sm text-slate-400">Kembali ke Dashboard untuk menyusun sesi ujian.</p>
      </div>
    );
  }

  const { answers, flagged, currentQuestionIndex, timeRemainingSeconds } = cbtState;
  const currentQuestion = cbtQuestions[currentQuestionIndex];

  // REALTIME TIMER
  useEffect(() => {
    const timer = setInterval(() => {
      tickTimerCBT();
    }, 1000);
    return () => clearInterval(timer);
  }, [tickTimerCBT]);

  // Anti-refresh warning handler
  useEffect(() => {
    const preventClose = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "Ujian sedang berlangsung! Jawaban Anda akan hilang jika Anda menyegarkan halaman.";
    };
    window.addEventListener('beforeunload', preventClose);
    return () => window.removeEventListener('beforeunload', preventClose);
  }, []);

  // Format Timer logic
  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Fullscreen support
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(err => {
        console.warn("Fullscreen request rejected", err);
      });
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handlePrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentIndexCBT(currentQuestionIndex - 1);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < cbtQuestions.length - 1) {
      setCurrentIndexCBT(currentQuestionIndex + 1);
    }
  };

  const handleFinish = () => {
    setShowConfirmModal(true);
  };

  const handleConfirmSubmit = async () => {
    setShowConfirmModal(false);
    setSubmitting(true);
    try {
      await submitCBT();
      onScoreSubmitted();
    } catch (e) {
      console.error(e);
      alert("Proses submit ukom gagal. Silakan coba kembali.");
    } finally {
      setSubmitting(false);
    }
  };

  // Auto-submit on timer end
  useEffect(() => {
    if (timeRemainingSeconds === 0) {
      // Auto submit instantly!
      (async () => {
        setSubmitting(true);
        try {
          await submitCBT();
          onScoreSubmitted();
        } catch (e) {
          console.error(e);
        } finally {
          setSubmitting(false);
        }
      })();
    }
  }, [timeRemainingSeconds, submitCBT, onScoreSubmitted]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col select-none transition-colors duration-300">
      
      {/* Top Professional CBT Header bar */}
      <header className="glassmorphism bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 py-3.5 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <span className="font-display font-extrabold text-sm sm:text-base tracking-tight bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-500 bg-clip-text text-transparent">
             CAT TRYOUT KOMPETENSI D3
          </span>
          <span className="hidden sm:inline px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-950 text-slate-400 font-medium text-[10px]">
             PETA SOAL: {cbtQuestions.length} BUTIR
          </span>
        </div>

        {/* Realtime Countdown Timer */}
        <div className="flex items-center gap-4">
          <div className={`flex items-center gap-2 px-4 py-1.5 rounded-xl border font-mono font-bold text-sm sm:text-base shadow-sm ${
            timeRemainingSeconds < 300 
              ? "bg-rose-50 dark:bg-rose-950/30 border-rose-200 text-rose-600 animate-pulse"
              : "bg-slate-100/50 dark:bg-slate-950/50 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300"
          }`}>
            <Clock className="w-4 h-4" />
            <span>{formatTime(timeRemainingSeconds)}</span>
          </div>

          <button
            onClick={toggleFullscreen}
            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-950 rounded-xl transition-colors border border-slate-150 dark:border-slate-800 text-slate-500 hover:text-slate-850"
            title="Toggle Layar Penuh"
          >
            <Maximize className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Dual Stage CBT Section */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 grid lg:grid-cols-4 gap-6 items-start">
        
        {/* Left Interactive Stage: Question, Vignette, and Options */}
        <div className="lg:col-span-3 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col min-h-[60vh]">
          
          {/* Header Area showing Vignette context */}
          <div className="p-5 sm:p-6 bg-slate-50 dark:bg-slate-950 border-b border-slate-150 dark:border-slate-850 flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
               Soal Nomor {currentQuestionIndex + 1}
            </span>
            <span className="px-3 py-1 bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 text-[11px] font-bold text-slate-500 rounded-lg">
               Kategori: {currentQuestion.category}
            </span>
          </div>

          {/* Vignette narrative case text */}
          <div className="p-6 sm:p-8 flex-1 space-y-6">
            <p className="text-slate-800 dark:text-slate-200 text-base sm:text-lg leading-relaxed font-normal whitespace-pre-wrap select-text">
               {currentQuestion.question}
            </p>

            {currentQuestion.imageUrl && (
              <div className="my-4 rounded-xl overflow-hidden max-w-md border border-slate-100 dark:border-slate-850">
                <img
                  src={currentQuestion.imageUrl}
                  alt="Vignette Illustration"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover"
                />
              </div>
            )}

            {/* A to E interactive option choices list */}
            <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-3.5">
              {[
                { key: 'A', text: currentQuestion.optionA },
                { key: 'B', text: currentQuestion.optionB },
                { key: 'C', text: currentQuestion.optionC },
                { key: 'D', text: currentQuestion.optionD },
                { key: 'E', text: currentQuestion.optionE }
              ].map(({ key, text }) => {
                const isSelected = answers[currentQuestion.id] === key;
                return (
                  <label
                    key={key}
                    className={`flex items-start gap-4 p-4 rounded-2xl border cursor-pointer select-none transition-all ${
                      isSelected
                        ? "bg-emerald-50/55 dark:bg-emerald-950/25 border-emerald-400 text-slate-850 dark:text-emerald-300 font-medium"
                        : "bg-slate-50/30 dark:bg-slate-950/10 border-slate-150 dark:border-slate-850 text-slate-700 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-950"
                    }`}
                  >
                    <input
                      type="radio"
                      name={`question-${currentQuestion.id}`}
                      checked={isSelected}
                      onChange={() => setAnswerForCBT(currentQuestion.id, key)}
                      className="mt-0.5 text-emerald-600 accent-emerald-500 focus:ring-emerald-500 w-4 h-4 shrink-0"
                    />
                    <div className="flex gap-2">
                       <span className="font-extrabold uppercase shrink-0">{key}.</span>
                       <span className="text-sm leading-relaxed">{text}</span>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Footer controls section */}
          <div className="p-5 sm:p-6 bg-slate-50 dark:bg-slate-950 border-t border-slate-150 dark:border-slate-850 flex flex-col sm:flex-row items-center justify-between gap-4">
            
            {/* Ragu-ragu switch button */}
            <button
               onClick={() => toggleFlagCBT(currentQuestion.id)}
               className={`w-full sm:w-auto px-5 py-2.5 rounded-xl border text-xs font-bold transition-colors flex items-center justify-center gap-2 ${
                 flagged.includes(currentQuestion.id)
                   ? "bg-amber-500 border-amber-500 text-white"
                   : "bg-white dark:bg-slate-900 border-amber-300 text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950"
               }`}
            >
              <AlertTriangle className="w-4 h-4" />
              {flagged.includes(currentQuestion.id) ? "★ Menandai Ragu-Ragu" : "Tandai Ragu-Ragu"}
            </button>

            {/* Previous / Next button deck */}
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={handlePrev}
                disabled={currentQuestionIndex === 0}
                className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 disabled:opacity-30 text-xs font-semibold hover:bg-slate-50 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> SEBELUMNYA
              </button>

              {currentQuestionIndex === cbtQuestions.length - 1 ? (
                <button
                  type="button"
                  onClick={handleFinish}
                  className="flex-1 sm:flex-none px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white text-xs font-bold rounded-xl shadow-md uppercase active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" /> SELESAIKAN UJIAN
                </button>
              ) : (
                <button
                  onClick={handleNext}
                  className="flex-1 sm:flex-none px-4 py-2.5 border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold hover:bg-slate-50 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  BERIKUTNYA <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

        </div>

        {/* Right Sidebar Stage: Question numbers grid */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 space-y-6">
          <div className="space-y-1 pb-4 border-b border-slate-100 dark:border-slate-800">
             <h4 className="font-display font-black text-sm">Navigasi Lembar Jawaban</h4>
             <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Map Soal Ujian</p>
          </div>

          {/* Quick Stats of inputs */}
          <div className="grid grid-cols-3 gap-2.5 text-[10px] uppercase font-bold text-center">
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 rounded-lg">
               <div>{Object.keys(answers).length}</div>
               <div className="opacity-80 mt-0.5">Selesai</div>
            </div>
            <div className="p-2 bg-amber-50 dark:bg-amber-950/20 text-amber-600 rounded-lg">
               <div>{flagged.length}</div>
               <div className="opacity-80 mt-0.5">Ragu</div>
            </div>
            <div className="p-2 bg-slate-50 dark:bg-slate-950/45 text-slate-400 rounded-lg">
               <div>{cbtQuestions.length - Object.keys(answers).length}</div>
               <div className="opacity-80 mt-0.5">Sisa</div>
            </div>
          </div>

          {/* Question Grid Map */}
          <div className="grid grid-cols-5 sm:grid-cols-6 lg:grid-cols-5 gap-2 max-h-[300px] overflow-y-auto pr-1">
            {cbtQuestions.map((q, idx) => {
              const isCurrent = idx === currentQuestionIndex;
              const isAnswered = !!answers[q.id];
              const isFlagged = flagged.includes(q.id);

              let badgeStyle = "bg-slate-100 dark:bg-slate-950 border-transparent text-slate-400 dark:text-slate-600";
              if (isFlagged) {
                badgeStyle = "bg-amber-500 text-white border-transparent";
              } else if (isAnswered) {
                badgeStyle = "bg-emerald-500 text-white border-transparent";
              }

              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentIndexCBT(idx)}
                  className={`w-full aspect-square text-xs font-extrabold rounded-xl border flex items-center justify-center transition-all ${badgeStyle} ${
                    isCurrent ? "ring-2 ring-indigo-500 scale-105 shadow-md border-indigo-500" : ""
                  }`}
                >
                  {(idx + 1).toString().padStart(2, '0')}
                </button>
              );
            })}
          </div>

          {/* Submit Action Finish Trigger */}
          <button
            onClick={handleFinish}
            disabled={submitting}
            className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white font-bold text-xs rounded-xl shadow-md uppercase active:scale-95 disabled:opacity-50 transition-all flex items-center justify-center gap-2 pt-3.5"
          >
            <CheckCircle2 className="w-4 h-4" /> Kumpulkan Jawaban (Selesai)
          </button>
        </div>

      </main>

      {/* Custom Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-amber-500/10 text-amber-500 rounded-full mx-auto flex items-center justify-center text-3xl">
                ⚠️
              </div>
              <h3 className="font-display font-black text-xl text-slate-950 dark:text-white">
                Selesaikan CBT Tryout?
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Apakah Anda benar-benar yakin ingin menyelesaikan sesi ujian sekarang dan mendapatkan analisis skoring?
              </p>
            </div>

            {/* Answer completion progress display */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-850 space-y-2 text-xs text-slate-700 dark:text-slate-350">
              <div className="flex justify-between items-center">
                <span>Total Butir Soal:</span>
                <span className="font-black text-slate-950 dark:text-white">{cbtQuestions.length} Soal</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Jawaban Terisi:</span>
                <span className="font-black text-emerald-600 dark:text-emerald-400">
                  {Object.keys(answers).length} Soal
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span>Belum Terjawab:</span>
                <span className="font-black text-slate-500">
                  {cbtQuestions.length - Object.keys(answers).length} Soal
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span>Ditandai Ragu-Ragu:</span>
                <span className="font-black text-amber-500">{flagged.length} Soal</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 py-3 border border-slate-250 dark:border-slate-800 rounded-xl text-xs font-black uppercase text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-950 hover:text-slate-700 dark:hover:text-slate-350 transition-all cursor-pointer"
              >
                Kembali (Periksa Soal)
              </button>
              <button
                type="button"
                onClick={handleConfirmSubmit}
                disabled={submitting}
                className="flex-1 py-3 bg-gradient-to-r from-emerald-600 to-teal-500 text-white rounded-xl text-xs font-black uppercase shadow-lg shadow-emerald-500/10 hover:shadow-emerald-500/20 active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {submitting ? "Memproses..." : "Ya, Selesaikan"}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
