import { Question } from '../types';

export const SAMPLE_QUESTIONS: Question[] = [
  {
    id: "q1",
    category: "Keperawatan Medikal Bedah (KMB)",
    question: "Seorang laki-laki berusia 45 tahun dirawat di ruang bedah dengan keluhan nyeri pasca-operasi apendektomi hari ke-1. Nyeri dirasakan seperti ditusuk-tusuk dengan skala nyeri 6 (1-10) terutama saat bergerak. Pasien tampak meringis kesakitan, memegangi perutnya, dan enggan diajak bergerak. TD 130/80 mmHg, Nadi 92 x/menit, Suhu 37,2°C, P 20 x/menit. Apakah diagnosis keperawatan yang utama bagi pasien tersebut?",
    optionA: "Nyeri akut berhubungan dengan agen pencedera fisik (prosedur bedah)",
    optionB: "Nyeri kronis berhubungan dengan infiltrasi tumor",
    optionC: "Gangguan mobilitas fisik berhubungan dengan kelemahan neuromuskular",
    optionD: "Risiko infeksi berhubungan dengan efek invasif pembedahan",
    optionE: "Intoleransi aktivitas berhubungan dengan kelemahan fisik",
    correctAnswer: "A",
    explanation: "Diagnosis keperawatan utama adalah nyeri akut. Batasan karakteristik terpenuhi: keluhan utama nyeri pasca-bedah hari ke-1 dengan onset mendadak, skala nyeri 6 (sedang-berat), durasi kurang dari 3 bulan, tampak meringis kesakitan, dan memegangi area nyeri.",
    createdAt: new Date().toISOString()
  },
  {
    id: "q2",
    category: "Keperawatan Anak",
    question: "Seorang anak laki-laki berusia 2 tahun dibawa ibunya ke Puskesmas dengan keluhan buang air besar cair sejak 2 hari yang lalu sebanyak 6 kali sehari. Hasil pengkajian: anak tampak rewel, mata cekung, turgor kulit kembali dalam waktu 3 detik, dan cubitan kulit perut kembali lambat. Berat badan anak 12 kg, suhu 37,8°C. Apakah tindakan keperawatan segera yang harus direncanakan?",
    optionA: "Pemberian cairan rehidrasi oralit 75 ml/kg BB dalam 3 jam pertama",
    optionB: "Pemberian nutrisi tinggi kalori secara enteral",
    optionC: "Melakukan kompres hangat pada dahi dan lipat paha",
    optionD: "Menganjurkan ibu untuk membatasi pemberian ASI",
    optionE: "Pemberian terapi antibiotika oral dosis tinggi sesuai resep",
    correctAnswer: "A",
    explanation: "Berdasarkan gejala mata cekung, turgor menurun, cubitan kembali lambat, anak mengalami dehidrasi ringan-sedang. Sesuai bagan MTBS, penanganan utama dehidrasi ringan-sedang adalah pemberian cairan oralit (Rencana Terapi B), yaitu 75 ml per kg BB dalam 3 jam pertama.",
    createdAt: new Date().toISOString()
  },
  {
    id: "q3",
    category: "Keperawatan Gawat Darurat & Kritis",
    question: "Seorang laki-laki berusia 50 tahun diantar ke UGD setelah mengalami kecelakaan lalu lintas. Pasien tidak sadarkan diri. Pemeriksaan fisik menunjukkan adanya deviasi trakea, pengembangan dada tidak simetris pada sisi kanan, dispnea berat, serta pelebaran vena jugularis. Suara napas pada paru kanan menghilang. TD 85/50 mmHg, Nadi 124 x/menit lemah, P 32 x/menit. Apakah tindakan darurat penyelamatan jiwa pertama yang harus segera dilakukan?",
    optionA: "Melakukan pemasangan jarum dekompresi (needle decompresson) di rongga dada kanan ICS 2 mid-klavikula",
    optionB: "Memasang pipa endotrakeal (ETT) untuk menjaga patensi jalan napas",
    optionC: "Melakukan tindakan RJP 30 kompresi berbanding 2 ventilasi",
    optionD: "Pemberian cairan kristaloid NaCl 0.9% secara bolus cepat 2 liter",
    optionE: "Melakukan foto rontgen thorax portable untuk penegakan diagnosis",
    correctAnswer: "A",
    explanation: "Pasien menunjukkan tanda klasikal tension pneumothorax (deviasi trakea, distensi vena leher, asimetri dada, syok obstruktif: TD rendah nadi cepat). Tindakan penyelamatan darurat (life saving) pertama adalah needle decompression pada sisi paru yang sakit (Sisi Kanan, ICS 2 Mid-Clavicular Line) untuk mengubah tension pneumothorax menjadi simple pneumothorax.",
    createdAt: new Date().toISOString()
  },
  {
    id: "q4",
    category: "Keperawatan Jiwa",
    question: "Seorang perempuan berusia 28 tahun dirawat di RS Jiwa dengan riwayat murung dan mengurung diri setelah diceraikan suaminya. Saat interaksi oleh perawat, pasien lebih suka menyendiri di pojok kamar, menolak makan bersama, menghindari kontak mata, menunduk, dan berbicara dengan suara sangat pelan serta singkat: 'Saya tidak ada gunanya lagi'. Apakah masalah keperawatan utama pada pasien tersebut?",
    optionA: "Harga diri rendah situasional",
    optionB: "Isolasi sosial",
    optionC: "Risiko perilaku kekerasan",
    optionD: "Gangguan persepsi sensori: halusinasi pendengaran",
    optionE: "Koping individu tidak efektif",
    correctAnswer: "A",
    explanation: "Ungkapan pasien 'Saya tidak ada gunanya lagi' disertai dengan menolak berinteraksi, menunduk, menghindari kontak mata, menunjukkan perasaan negatif terhadap diri sendiri akibat stressors kehilangan (perceraian). Ini merupakan karakteristik utama Harga Diri Rendah (HDR).",
    createdAt: new Date().toISOString()
  },
  {
    id: "q5",
    category: "Keperawatan Maternitas",
    question: "Seorang ibu berusia 26 tahun G1P0A0 hamil 36 minggu datang ke poliklinik obstetri untuk pemeriksaan rutin. Ibu mengeluh kakinya sering kram dan bengkak di malam hari. Hasil pemeriksaan: TD 120/80 mmHg, denyut jantung janin 140 kali/menit reguler, tinggi fundus uteri 32 cm. Edema derajat +1 pada kaki kanan dan kiri. Pemeriksaan urin protein menunjukkan hasil negatif. Apakah edukasi mandiri utama yang perlu disampaikan untuk mengatasi keluhan tersebut?",
    optionA: "Menyarankan ibu untuk tidur miring kiri dan mengganjal kaki dengan bantal saat berbaring",
    optionB: "Merekomendasikan istirahat baring mutlak (bed rest) sepanjang hari",
    optionC: "Merujuk pasien untuk melakukan persalinan sesar darurat",
    optionD: "Pemberian diuretik oral dosis rendah sesuai resep dokter",
    optionE: "Membatasi konsumsi asupan air minum harian hingga kurang dari 1 liter",
    correctAnswer: "A",
    explanation: "Edema perifer fisiologis pada akhir kehamilan disebabkan oleh bendungan aliran vena balik akibat penekanan uterus gravid terhadap vena kava inferior. Edukasi yang aman dan efektif adalah berbaring miring ke kiri untuk mengurangi tekanan uterus pada pembuluh darah besar serta memosisikan kaki lebih tinggi memakai bantal saat tidur untuk meningkatkan venous return.",
    createdAt: new Date().toISOString()
  },
  {
    id: "q6",
    category: "Management Keperawatan",
    question: "Di suatu bangsal rawat inap keperawatan, kepala ruangan mengamati bahwa sebagian perawat pelaksana sering terlambat saat timbang terima shift pagi ke sore. Model penugasan asuhan keperawatan yang diterapkan saat ini adalah Metode Tim. Kepala ruangan bermaksud menyelenggarakan rapat bulanan untuk merumuskan ulang komitmen profesionalitas staf bersama perawat primer. Apakah fungsi manajemen keperawatan yang sedang diterapkan?",
    optionA: "Fungsi Pengorganisasian (Organizing)",
    optionB: "Fungsi Perencanaan (Planning)",
    optionC: "Fungsi Pengarahan (Directing/Actuating)",
    optionD: "Fungsi Pengawasan dan Pengendalian (Controlling)",
    optionE: "Fungsi Ketenagaan (Staffing)",
    correctAnswer: "D",
    explanation: "Fungsi pengawasan dan pengendalian (controlling) mencakup pemantauan kinerja staf terhadap standar, mengidentifikasi penyimpangan (perawat terlambat timbang terima), serta melakukan langkah korektif (rapat formulasi komitmen staf) agar asuhan keperawatan tetap berjalan optimal sesuai standar operasional prosedur.",
    createdAt: new Date().toISOString()
  }
];
