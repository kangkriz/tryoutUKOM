import { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import LandingPage from './components/LandingPage';
import LoginPage from './components/LoginPage';
import ParticipantDashboard from './components/ParticipantDashboard';
import AdminDashboard from './components/AdminDashboard';
import CBTExamPage from './components/CBTExamPage';
import ResultsPage from './components/ResultsPage';
import ReviewAnswersPage from './components/ReviewAnswersPage';
import KisiKisiPage from './components/KisiKisiPage';
import InformationPage from './components/InformationPage';
import HistoryPage from './components/HistoryPage';
import QuestionBankPage from './components/QuestionBankPage';
import ManageUsersPage from './components/ManageUsersPage';

import { 
  ShieldCheck, LogOut, Sun, Moon, Sparkles, LayoutDashboard, 
  Users, BookOpen, Clock, Info, Award, UserCheck, KeyRound, Menu, X, Landmark, ArrowLeft
} from 'lucide-react';

function MainAppContent() {
  const { currentUser, logout, theme, toggleTheme, cbtState, startCBT } = useApp();
  
  // Custom navigation
  const [view, setView] = useState<'landing' | 'login' | 'app' | 'exam' | 'results' | 'review'>('landing');
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedResultId, setSelectedResultId] = useState<string | null>(null);

  // If exam is active, render CBT mode immediately to avoid cheating by clicking other tabs!
  if (cbtState && cbtState.isActive) {
    return (
      <CBTExamPage 
        onScoreSubmitted={() => {
          setView('results');
        }} 
      />
    );
  }

  // Back from CBT results directly
  if (view === 'results') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 py-12 px-4 transition-colors">
        <ResultsPage 
          onBackToHome={() => {
            setView('app');
            setCurrentTab('dashboard');
          }}
          onReviewAnswers={() => {
            setView('review');
          }}
        />
      </div>
    );
  }

  // Reviewing student correct answers and explanations
  if (view === 'review') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 py-12 px-4 transition-colors">
        <ReviewAnswersPage 
          selectedResultId={selectedResultId}
          onBackToResults={() => {
             if (selectedResultId) {
                setSelectedResultId(null);
                setView('app');
                setCurrentTab('history');
             } else {
                setView('results');
             }
          }}
        />
      </div>
    );
  }

  // Show Landing Page
  if (view === 'landing' && !currentUser) {
    return <LandingPage onStartLogin={() => setView('login')} />;
  }

  // Show Login form
  if (view === 'login' && !currentUser) {
    return (
      <LoginPage 
        onBack={() => setView('landing')} 
      />
    );
  }

  // If user is logged but view state remains landing/login, safely switch over
  if (currentUser && (view === 'landing' || view === 'login')) {
     setView('app');
  }

  // Main Authenticated Application Skeleton
  const isAdmin = currentUser?.role === 'admin';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors duration-300">
      
      {/* Dynamic authenticated navigation header */}
      <header className="glassmorphism border-b border-slate-100 dark:border-slate-850/60 sticky top-0 z-30 bg-white/80 dark:bg-slate-950/85 backdrop-blur-md px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
         <div className="flex items-center gap-3">
            <button
               onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
               className="md:hidden p-2 text-slate-500 hover:text-slate-800 dark:hover:text-white rounded-lg border border-slate-200 dark:border-slate-800"
            >
               {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-white rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden flex items-center justify-center p-0.5">
                <img
                  src="https://iili.io/C25elun.jpg"
                  alt="Logo"
                  className="w-full h-full object-contain rounded-lg"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="font-display font-extrabold text-base tracking-tight bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">
                CBT Perawat D3
              </span>
            </div>
         </div>

         {/* Action buttons list */}
         <div className="flex items-center gap-3">
            {/* Theme switcher */}
            <button
               onClick={toggleTheme}
               className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors"
               title="Ganti Tema"
            >
               {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Profile greeting summary */}
            <div className="hidden sm:flex flex-col items-end text-right">
              <span className="text-xs font-extrabold font-display leading-tight">{currentUser?.name}</span>
               <span className="text-[10px] text-emerald-500 font-bold uppercase tracking-wide">
                 {isAdmin ? "ADMIN PORTAL" : "PESERTA CBT"}
               </span>
            </div>

            {/* Logout trigger button */}
            <button
               onClick={() => {
                  logout();
                  setView('landing');
               }}
               className="flex items-center gap-1.5 px-3.5 py-2 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/20 rounded-xl text-slate-500 text-xs font-bold border border-transparent hover:border-rose-100 dark:hover:border-rose-900/30 transition-all cursor-pointer"
            >
               <LogOut className="w-4.5 h-4.5" />
               <span className="hidden sm:inline">Keluar</span>
            </button>
         </div>
      </header>

      <div className="flex-1 flex relative">
        
         {/* Sidebar Navigation */}
         <aside className={`fixed inset-y-0 left-0 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-850 p-6 space-y-8 z-20 transform md:transform-none md:static transition-transform duration-300 flex flex-col justify-between ${
            mobileMenuOpen ? 'translate-x-0 pt-20' : '-translate-x-full'
         }`}>
            <div className="space-y-6">
               <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Utama Menu</p>
               
               <nav className="space-y-1.5">
                  {/* Participant and Admin standard index */}
                  <button
                     onClick={() => { setCurrentTab('dashboard'); setMobileMenuOpen(false); }}
                     className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                        currentTab === 'dashboard'
                           ? 'bg-gradient-to-r from-emerald-600/10 to-teal-500/10 text-emerald-600 dark:text-emerald-400 border-l-4 border-emerald-500'
                           : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-950 hover:text-slate-850'
                     }`}
                  >
                     <LayoutDashboard className="w-4.5 h-4.5 shrink-0" /> Dashboard Portal
                  </button>

                  {/* Admin Specific Sidebar Buttons */}
                  {isAdmin && (
                    <>
                       <button
                          onClick={() => { setCurrentTab('users'); setMobileMenuOpen(false); }}
                          className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                             currentTab === 'users'
                                ? 'bg-gradient-to-r from-emerald-600/10 to-teal-500/10 text-emerald-600 dark:text-emerald-400 border-l-4 border-emerald-500'
                                : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-950 hover:text-slate-850'
                          }`}
                       >
                          <Users className="w-4.5 h-4.5 shrink-0" /> Kelola Peserta
                       </button>

                       <button
                          onClick={() => { setCurrentTab('questions'); setMobileMenuOpen(false); }}
                          className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                             currentTab === 'questions'
                                ? 'bg-gradient-to-r from-emerald-600/10 to-teal-500/10 text-emerald-600 dark:text-emerald-400 border-l-4 border-emerald-500'
                                : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-950 hover:text-slate-850'
                          }`}
                       >
                          <BookOpen className="w-4.5 h-4.5 shrink-0" /> Bank Naskah CBT
                       </button>
                    </>
                  )}

                  {/* Shared Sidebar Buttons */}
                  <button
                     onClick={() => { setCurrentTab('kisiKisi'); setMobileMenuOpen(false); }}
                     className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                        currentTab === 'kisiKisi'
                           ? 'bg-gradient-to-r from-emerald-600/10 to-teal-500/10 text-emerald-600 dark:text-emerald-400 border-l-4 border-emerald-500'
                           : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-950 hover:text-slate-850'
                     }`}
                  >
                     <Landmark className="w-4.5 h-4.5 shrink-0" /> Kisi-Kisi Kurikulum
                  </button>

                  <button
                     onClick={() => { setCurrentTab('information'); setMobileMenuOpen(false); }}
                     className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                        currentTab === 'information'
                           ? 'bg-gradient-to-r from-emerald-600/10 to-teal-500/10 text-emerald-600 dark:text-emerald-400 border-l-4 border-emerald-500'
                           : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-950 hover:text-slate-850'
                     }`}
                  >
                     <Info className="w-4.5 h-4.5 shrink-0" /> {isAdmin ? "Input & Kelola Informasi" : "Pengumuman Resmi"}
                  </button>

                  <button
                     onClick={() => { setCurrentTab('history'); setMobileMenuOpen(false); }}
                     className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                        currentTab === 'history'
                           ? 'bg-gradient-to-r from-emerald-600/10 to-teal-500/10 text-emerald-600 dark:text-emerald-400 border-l-4 border-emerald-500'
                           : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-950 hover:text-slate-850'
                     }`}
                  >
                     <Award className="w-4.5 h-4.5 shrink-0" /> Riwayat Nilai
                  </button>
               </nav>
            </div>

            {/* Sidebar bottom decoration card */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-850 text-center space-y-2">
               <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest block">CAT UKOM D3</span>
               <p className="text-[10px] text-slate-500 leading-normal">Edisi 2026 AIPViKI Nasional.</p>
            </div>
         </aside>

         {/* Content container area */}
         <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full overflow-hidden space-y-6">
            {currentTab !== 'dashboard' && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 px-5 py-4 rounded-2xl border border-slate-100 dark:border-slate-850/60 shadow-sm transition-all mb-4">
                 <button 
                  onClick={() => setCurrentTab('dashboard')}
                  className="group flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 border border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-800 text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 text-xs font-bold transition-all shadow-sm cursor-pointer"
                 >
                   <ArrowLeft className="w-4.5 h-4.5 transition-transform group-hover:-translate-x-1" />
                   <span>Kembali ke Dashboard Utama</span>
                 </button>
                 <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 dark:text-slate-500">
                      Halaman Aktif: {currentTab === 'users' ? 'Kelola Peserta' : 
                                      currentTab === 'questions' ? 'Bank Naskah CBT' : 
                                      currentTab === 'kisiKisi' ? 'Kisi-Kisi Kurikulum' : 
                                      currentTab === 'information' ? 'Pengumuman Resmi' : 
                                      currentTab === 'history' ? 'Riwayat Nilai' : ''}
                    </span>
                 </div>
              </div>
            )}

            {currentTab === 'dashboard' && (
              isAdmin ? (
                <AdminDashboard 
                   onNavigatePage={(page) => setCurrentTab(page)} 
                />
              ) : (
                <ParticipantDashboard 
                   onStartExam={(count, category, model) => {
                      startCBT(count, category, model);
                   }}
                   onNavigatePage={(page) => setCurrentTab(page)}
                />
              )
            )}

            {currentTab === 'users' && isAdmin && <ManageUsersPage />}
            {currentTab === 'questions' && isAdmin && <QuestionBankPage />}
            {currentTab === 'kisiKisi' && <KisiKisiPage />}
            {currentTab === 'information' && <InformationPage />}
            {currentTab === 'history' && (
               <HistoryPage 
                  onReviewSelectedResult={(id) => {
                     // Set view to review specifically
                     setSelectedResultId(id);
                     setView('review');
                  }}
               />
            )}
         </main>

      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
