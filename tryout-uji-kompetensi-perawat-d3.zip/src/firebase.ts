import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc, getDocs, collection, deleteDoc, updateDoc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { SAMPLE_QUESTIONS } from './data/sampleQuestions';
import { User as AppUser, UserRole, AccountStatus, Question, ExamResult, KisiKisi, Announcement } from './types';

// Detect if configuring with dummy placeholders
const isMockConfig = !firebaseConfig.apiKey || firebaseConfig.apiKey.includes('mock-api-key') || firebaseConfig.apiKey === '';

let app;
let db: any;
let auth: any;

if (!isMockConfig) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    db = getFirestore(app, (firebaseConfig as any).firestoreDatabaseId);
    auth = getAuth(app);
  } catch (err) {
    console.warn("Firebase initialization failed, falling back to Local Mock DB:", err);
  }
}

// Validate connection to Firestore as per Integration Skill guidelines
async function testFirestoreConnection() {
  if (db) {
    try {
      await getDocFromServer(doc(db, 'test', 'connection'));
      console.log("Firestore connection test completed successfully.");
    } catch (error) {
      if (error instanceof Error && error.message.includes('offline')) {
        console.error("Firestore is offline. Please check your Firebase project configuration.");
      } else {
        console.log("Firestore network validated.");
      }
    }
  }
}
testFirestoreConnection();

export { db, auth };

/**
 * Recursively removes any keys with `undefined` values from an object,
 * making it safe to write to Firestore which rejects `undefined` values.
 */
function cleanUndefined(obj: any): any {
  if (obj === null || obj === undefined) return null;
  if (Array.isArray(obj)) {
    return obj.map(cleanUndefined);
  }
  if (typeof obj === 'object') {
    if (obj.constructor && obj.constructor.name !== 'Object' && obj.constructor.name !== 'Array') {
      return obj;
    }
    const clean: any = {};
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (val !== undefined) {
        clean[key] = cleanUndefined(val);
      }
    }
    return clean;
  }
  return obj;
}

// ERROR HANDLERS COMPLIANT WITH THE FIREBASE INTEGRATION SKILL
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || 'anonymous',
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || false,
      isAnonymous: auth?.currentUser?.isAnonymous || true,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// -------------------------------------------------------------
// HYBRID CLIENT DATABASE REPOSITORY (FIRESTORE + LOCAL STORAGE FALLBACK)
// -------------------------------------------------------------

// Local storage storage keys
const LS_KEYS = {
  USERS: 'cbt_ukom_users',
  QUESTIONS: 'cbt_ukom_questions',
  RESULTS: 'cbt_ukom_results',
  KISIKISI: 'cbt_ukom_kisikisi',
  ANNOUNCEMENTS: 'cbt_ukom_announcements'
};

// Initial seed states
const DEFAULT_USERS: AppUser[] = [
  {
    id: "admin-1",
    name: "Dr. Namira Nur, S.Kep., Ns.",
    email: "namirastore66@gmail.com",
    role: UserRole.ADMIN,
    status: AccountStatus.ACTIVE,
    password: "admin123",
    createdAt: new Date().toISOString()
  },
  {
    id: "admin-2",
    name: "Administrator CBT",
    email: "admin@ukom.id",
    role: UserRole.ADMIN,
    status: AccountStatus.ACTIVE,
    password: "admin123",
    createdAt: new Date().toISOString()
  },
  {
    id: "peserta-1",
    name: "Rian Hermawan",
    email: "peserta@ukom.id",
    role: UserRole.USER,
    status: AccountStatus.ACTIVE,
    password: "peserta123",
    createdAt: new Date().toISOString()
  },
  {
    id: "peserta-2",
    name: "Siti Rahmawati",
    email: "siti@ukom.id",
    role: UserRole.USER,
    status: AccountStatus.ACTIVE,
    password: "password123",
    createdAt: new Date().toISOString()
  }
];

const DEFAULT_ANNOUNCEMENTS: Announcement[] = [
  {
    id: "ann-1",
    title: "Pendaftaran Tryout Nasional Gelombang II Dibuka",
    content: "Diberitahukan kepada seluruh mahasiswa D3 Keperawatan tingkat akhir, Tryout berbasis CAT nasional akan dilaksanakan segera. Silakan pelajari kisi-kisi dan silabus terbaru yang tersedia di dashboard masing-masing peserta.",
    bannerUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200",
    createdAt: new Date().toISOString()
  },
  {
    id: "ann-2",
    title: "Tips Lulus UKOM D3 Keperawatan Skoring Tinggi",
    content: "1. Fokus pada asuhan keperawatan 7 departemen utama.\n2. Latih manajemen waktu: 1 soal = 1 menit!\n3. Pelajari kata kunci (vignette klinis) di setiap soal sebelum beralih ke pilihan jawaban.\n4. Gunakan eliminasi opsi jawaban.",
    bannerUrl: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=1200",
    createdAt: new Date().toISOString()
  }
];

const DEFAULT_KISIKISI: KisiKisi[] = [
  {
    id: "kisi-1",
    category: "Keperawatan Medikal Bedah (KMB)",
    title: "Asuhan Keperawatan Gangguan Sistem Respirasi",
    content: "Topik utama meliputi pengkajian bersihan jalan napas tidak efektif, pola napas tidak efektif, gangguan pertukaran gas. Intervensi keperawatan primer: fisioterapi dada, batuk efektif, suctioning, penyesuaian posisi semi-fowler/fowler, oksigenasi sirkuit lancar, penatalaksanaan nebulisasi.",
    createdAt: new Date().toISOString()
  },
  {
    id: "kisi-2",
    category: "Keperawatan Gawat Darurat & Kritis",
    title: "Triase Lapangan dan Bantuan Hidup Dasar (BHD)",
    content: "Penilaian kategori triase merah (resusitasi), kuning (darurat), hijau (non-darurat), hitam (meninggal). Penggunaan algoritma RJP AHA terbaru: kompresi dada kecepatan 100-120 x/menit, kedalaman 5-6 cm, rasio kompresi-ventilasi 30:2 pada pasien dewasa dengan satu atau dua penyelamat.",
    createdAt: new Date().toISOString()
  }
];

// Initialize local storages helper safely
function getLocalStore<T>(key: string, defaultVal: T[]): T[] {
  try {
    const saved = localStorage.getItem(key);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  // Seed initial value
  localStorage.setItem(key, JSON.stringify(defaultVal));
  return defaultVal;
}

function saveLocalStore<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// Global static cache for fallback operations
const localDB = {
  users: getLocalStore<AppUser>(LS_KEYS.USERS, DEFAULT_USERS),
  questions: getLocalStore<Question>(LS_KEYS.QUESTIONS, SAMPLE_QUESTIONS),
  results: getLocalStore<ExamResult>(LS_KEYS.RESULTS, []),
  kisikisi: getLocalStore<KisiKisi>(LS_KEYS.KISIKISI, DEFAULT_KISIKISI),
  announcements: getLocalStore<Announcement>(LS_KEYS.ANNOUNCEMENTS, DEFAULT_ANNOUNCEMENTS)
};

// EXPORT REPOSITORY FUNCTIONS WHICH AUTO-CHECK FIRESTORE WORKING AND SYNC
export const repository = {
  // --- USERS ---
  async getUsers(): Promise<AppUser[]> {
    if (db) {
      try {
        const querySnapshot = await getDocs(collection(db, 'users'));
        const users: AppUser[] = [];
        querySnapshot.forEach((docSnap) => {
          users.push(docSnap.data() as AppUser);
        });
        // Sync local
        localDB.users = users;
        saveLocalStore(LS_KEYS.USERS, users);
        return users;
      } catch (err) {
        console.warn("Firestore error reading users, using Local DB", err);
      }
    }
    return getLocalStore<AppUser>(LS_KEYS.USERS, DEFAULT_USERS);
  },

  async saveUser(user: AppUser): Promise<void> {
    // Save locally
    const list = getLocalStore<AppUser>(LS_KEYS.USERS, DEFAULT_USERS);
    const idx = list.findIndex(u => u.id === user.id);
    if (idx >= 0) list[idx] = user;
    else list.push(user);
    saveLocalStore(LS_KEYS.USERS, list);
    localDB.users = list;

    if (db) {
      try {
        await setDoc(doc(db, 'users', user.id), cleanUndefined(user));
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${user.id}`);
      }
    }
  },

  async deleteUser(userId: string): Promise<void> {
    const list = getLocalStore<AppUser>(LS_KEYS.USERS, DEFAULT_USERS).filter(u => u.id !== userId);
    saveLocalStore(LS_KEYS.USERS, list);
    localDB.users = list;

    if (db) {
      try {
        await deleteDoc(doc(db, 'users', userId));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `users/${userId}`);
      }
    }
  },

  // --- QUESTIONS ---
  async getQuestions(): Promise<Question[]> {
    if (db) {
      try {
        const querySnapshot = await getDocs(collection(db, 'questions'));
        const questions: Question[] = [];
        querySnapshot.forEach((docSnap) => {
          questions.push(docSnap.data() as Question);
        });
        if (questions.length > 0) {
          localDB.questions = questions;
          saveLocalStore(LS_KEYS.QUESTIONS, questions);
          return questions;
        }
      } catch (err) {
        console.warn("Firestore error reading questions, using Local DB", err);
      }
    }
    return getLocalStore<Question>(LS_KEYS.QUESTIONS, SAMPLE_QUESTIONS);
  },

  async saveQuestion(q: Question): Promise<void> {
    const list = getLocalStore<Question>(LS_KEYS.QUESTIONS, SAMPLE_QUESTIONS);
    const idx = list.findIndex(item => item.id === q.id);
    if (idx >= 0) list[idx] = q;
    else list.push(q);
    saveLocalStore(LS_KEYS.QUESTIONS, list);
    localDB.questions = list;

    if (db) {
      try {
        await setDoc(doc(db, 'questions', q.id), cleanUndefined(q));
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `questions/${q.id}`);
      }
    }
  },

  async deleteQuestion(id: string): Promise<void> {
    const list = getLocalStore<Question>(LS_KEYS.QUESTIONS, SAMPLE_QUESTIONS).filter(item => item.id !== id);
    saveLocalStore(LS_KEYS.QUESTIONS, list);
    localDB.questions = list;

    if (db) {
      try {
        await deleteDoc(doc(db, 'questions', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `questions/${id}`);
      }
    }
  },

  // --- RESULTS ---
  async getResults(): Promise<ExamResult[]> {
    if (db) {
      try {
        const querySnapshot = await getDocs(collection(db, 'results'));
        const results: ExamResult[] = [];
        querySnapshot.forEach((docSnap) => {
          results.push(docSnap.data() as ExamResult);
        });
        localDB.results = results;
        saveLocalStore(LS_KEYS.RESULTS, results);
        return results;
      } catch (err) {
        console.warn("Firestore error reading results, using Local DB", err);
      }
    }
    return getLocalStore<ExamResult>(LS_KEYS.RESULTS, []);
  },

  async saveResult(res: ExamResult): Promise<void> {
    const list = getLocalStore<ExamResult>(LS_KEYS.RESULTS, []);
    list.push(res);
    saveLocalStore(LS_KEYS.RESULTS, list);
    localDB.results = list;

    if (db) {
      try {
        await setDoc(doc(db, 'results', res.id), cleanUndefined(res));
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `results/${res.id}`);
      }
    }
  },

  async deleteResult(id: string): Promise<void> {
    const list = getLocalStore<ExamResult>(LS_KEYS.RESULTS, []).filter(item => item.id !== id);
    saveLocalStore(LS_KEYS.RESULTS, list);
    localDB.results = list;

    if (db) {
      try {
        await deleteDoc(doc(db, 'results', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `results/${id}`);
      }
    }
  },

  // --- KISI-KISI ---
  async getKisiKisi(): Promise<KisiKisi[]> {
    if (db) {
      try {
        const querySnapshot = await getDocs(collection(db, 'kisiKisi'));
        const list: KisiKisi[] = [];
        querySnapshot.forEach((docSnap) => {
          list.push(docSnap.data() as KisiKisi);
        });
        if (list.length > 0) {
          localDB.kisikisi = list;
          saveLocalStore(LS_KEYS.KISIKISI, list);
          return list;
        }
      } catch (err) {
        console.warn("Firestore error reading kisiKisi, using Local DB", err);
      }
    }
    return getLocalStore<KisiKisi>(LS_KEYS.KISIKISI, DEFAULT_KISIKISI);
  },

  async saveKisiKisi(kisi: KisiKisi): Promise<void> {
    const list = getLocalStore<KisiKisi>(LS_KEYS.KISIKISI, DEFAULT_KISIKISI);
    const idx = list.findIndex(item => item.id === kisi.id);
    if (idx >= 0) list[idx] = kisi;
    else list.push(kisi);
    saveLocalStore(LS_KEYS.KISIKISI, list);
    localDB.kisikisi = list;

    if (db) {
      try {
        await setDoc(doc(db, 'kisiKisi', kisi.id), cleanUndefined(kisi));
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `kisiKisi/${kisi.id}`);
      }
    }
  },

  async deleteKisiKisi(id: string): Promise<void> {
    const list = getLocalStore<KisiKisi>(LS_KEYS.KISIKISI, DEFAULT_KISIKISI).filter(item => item.id !== id);
    saveLocalStore(LS_KEYS.KISIKISI, list);
    localDB.kisikisi = list;

    if (db) {
      try {
        await deleteDoc(doc(db, 'kisiKisi', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `kisiKisi/${id}`);
      }
    }
  },

  // --- ANNOUNCEMENTS ---
  async getAnnouncements(): Promise<Announcement[]> {
    if (db) {
      try {
        const querySnapshot = await getDocs(collection(db, 'announcements'));
        const list: Announcement[] = [];
        querySnapshot.forEach((docSnap) => {
          list.push(docSnap.data() as Announcement);
        });
        if (list.length > 0) {
          localDB.announcements = list;
          saveLocalStore(LS_KEYS.ANNOUNCEMENTS, list);
          return list;
        }
      } catch (err) {
         console.warn("Firestore error reading announcements, using Local DB", err);
      }
    }
    return getLocalStore<Announcement>(LS_KEYS.ANNOUNCEMENTS, DEFAULT_ANNOUNCEMENTS);
  },

  async saveAnnouncement(ann: Announcement): Promise<void> {
    const list = getLocalStore<Announcement>(LS_KEYS.ANNOUNCEMENTS, DEFAULT_ANNOUNCEMENTS);
    const idx = list.findIndex(item => item.id === ann.id);
    if (idx >= 0) list[idx] = ann;
    else list.push(ann);
    saveLocalStore(LS_KEYS.ANNOUNCEMENTS, list);
    localDB.announcements = list;

    if (db) {
      try {
        await setDoc(doc(db, 'announcements', ann.id), cleanUndefined(ann));
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `announcements/${ann.id}`);
      }
    }
  },

  async deleteAnnouncement(id: string): Promise<void> {
    const list = getLocalStore<Announcement>(LS_KEYS.ANNOUNCEMENTS, DEFAULT_ANNOUNCEMENTS).filter(item => item.id !== id);
    saveLocalStore(LS_KEYS.ANNOUNCEMENTS, list);
    localDB.announcements = list;

    if (db) {
      try {
        await deleteDoc(doc(db, 'announcements', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `announcements/${id}`);
      }
    }
  }
};
