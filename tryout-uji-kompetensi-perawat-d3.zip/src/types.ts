/**
 * Types definition file for CBT Tryout Uji Kompetensi Perawat D3
 */

export enum UserRole {
  ADMIN = 'admin',
  USER = 'user'
}

export enum AccountStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive'
}

export interface User {
  id: string; // auth uid / simulated uid
  name: string;
  email: string;
  role: UserRole;
  status: AccountStatus;
  password?: string; // used for simple password fallback
  createdAt: string;
}

export interface Question {
  id: string;
  category: string; // KMB, Anak, Maternitas, Jiwa, Gawat Darurat, etc.
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  optionE: string;
  correctAnswer: 'A' | 'B' | 'C' | 'D' | 'E';
  explanation: string;
  imageUrl?: string;
  model?: string; // e.g. 'Model 1', 'Model 2', etc.
  createdAt: string;
}

export interface ExamResult {
  id: string;
  userId: string;
  userName: string;
  score: number;
  correctCount: number;
  wrongCount: number;
  percentage: number;
  isPassed: boolean;
  answers: { [questionId: string]: string }; // Map target questionId -> answer chosen e.g. "A"
  flagged: string[]; // List of flagged questionIds (ragu-ragu)
  completedAt: string;
}

export interface KisiKisi {
  id: string;
  category: string;
  title: string;
  content: string;
  fileUrl?: string;
  createdAt: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  bannerUrl?: string;
  createdAt: string;
}

export interface CBTActiveState {
  answers: { [questionId: string]: string };
  flagged: string[]; // ragu-ragu questions
  currentQuestionIndex: number;
  timeRemainingSeconds: number; // calculated countdown
  isActive: boolean;
  isCompleted: boolean;
  isFullscreen: boolean;
}

export const NURSE_CATEGORIES = [
  "Keperawatan Medikal Bedah (KMB)",
  "Keperawatan Maternitas",
  "Keperawatan Anak",
  "Keperawatan Jiwa",
  "Keperawatan Keluarga",
  "Keperawatan Gerontik",
  "Keperawatan Gawat Darurat & Kritis",
  "Manajemen Keperawatan"
];
